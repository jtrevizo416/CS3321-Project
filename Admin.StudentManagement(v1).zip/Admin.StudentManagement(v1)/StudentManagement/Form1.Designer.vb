﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IndexLabel As System.Windows.Forms.Label
        Dim Student_IDLabel As System.Windows.Forms.Label
        Dim First_NameLabel As System.Windows.Forms.Label
        Dim Last_NameLabel As System.Windows.Forms.Label
        Dim Date_Of_BirthLabel As System.Windows.Forms.Label
        Dim GenderLabel As System.Windows.Forms.Label
        Dim PasswordLabel As System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Student_InformationDataSet = New StudentManagement.Student_InformationDataSet()
        Me.Student_InfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_InfoTableAdapter = New StudentManagement.Student_InformationDataSetTableAdapters.Student_InfoTableAdapter()
        Me.TableAdapterManager = New StudentManagement.Student_InformationDataSetTableAdapters.TableAdapterManager()
        Me.Student_InfoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IndexTextBox = New System.Windows.Forms.TextBox()
        Me.Student_IDTextBox = New System.Windows.Forms.TextBox()
        Me.First_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Last_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Date_Of_BirthTextBox = New System.Windows.Forms.TextBox()
        Me.GenderTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.btnDeleteStudent = New System.Windows.Forms.Button()
        IndexLabel = New System.Windows.Forms.Label()
        Student_IDLabel = New System.Windows.Forms.Label()
        First_NameLabel = New System.Windows.Forms.Label()
        Last_NameLabel = New System.Windows.Forms.Label()
        Date_Of_BirthLabel = New System.Windows.Forms.Label()
        GenderLabel = New System.Windows.Forms.Label()
        PasswordLabel = New System.Windows.Forms.Label()
        CType(Me.Student_InformationDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_InfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_InfoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IndexLabel
        '
        IndexLabel.AutoSize = True
        IndexLabel.Location = New System.Drawing.Point(57, 156)
        IndexLabel.Name = "IndexLabel"
        IndexLabel.Size = New System.Drawing.Size(36, 13)
        IndexLabel.TabIndex = 2
        IndexLabel.Text = "Index:"
        '
        'Student_IDLabel
        '
        Student_IDLabel.AutoSize = True
        Student_IDLabel.Location = New System.Drawing.Point(206, 156)
        Student_IDLabel.Name = "Student_IDLabel"
        Student_IDLabel.Size = New System.Drawing.Size(61, 13)
        Student_IDLabel.TabIndex = 4
        Student_IDLabel.Text = "Student ID:"
        '
        'First_NameLabel
        '
        First_NameLabel.AutoSize = True
        First_NameLabel.Location = New System.Drawing.Point(57, 195)
        First_NameLabel.Name = "First_NameLabel"
        First_NameLabel.Size = New System.Drawing.Size(60, 13)
        First_NameLabel.TabIndex = 6
        First_NameLabel.Text = "First Name:"
        '
        'Last_NameLabel
        '
        Last_NameLabel.AutoSize = True
        Last_NameLabel.Location = New System.Drawing.Point(206, 195)
        Last_NameLabel.Name = "Last_NameLabel"
        Last_NameLabel.Size = New System.Drawing.Size(61, 13)
        Last_NameLabel.TabIndex = 8
        Last_NameLabel.Text = "Last Name:"
        '
        'Date_Of_BirthLabel
        '
        Date_Of_BirthLabel.AutoSize = True
        Date_Of_BirthLabel.Location = New System.Drawing.Point(57, 234)
        Date_Of_BirthLabel.Name = "Date_Of_BirthLabel"
        Date_Of_BirthLabel.Size = New System.Drawing.Size(71, 13)
        Date_Of_BirthLabel.TabIndex = 10
        Date_Of_BirthLabel.Text = "Date Of Birth:"
        '
        'GenderLabel
        '
        GenderLabel.AutoSize = True
        GenderLabel.Location = New System.Drawing.Point(207, 234)
        GenderLabel.Name = "GenderLabel"
        GenderLabel.Size = New System.Drawing.Size(45, 13)
        GenderLabel.TabIndex = 12
        GenderLabel.Text = "Gender:"
        '
        'PasswordLabel
        '
        PasswordLabel.AutoSize = True
        PasswordLabel.Location = New System.Drawing.Point(61, 270)
        PasswordLabel.Name = "PasswordLabel"
        PasswordLabel.Size = New System.Drawing.Size(56, 13)
        PasswordLabel.TabIndex = 14
        PasswordLabel.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(355, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(365, 39)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Management"
        '
        'Student_InformationDataSet
        '
        Me.Student_InformationDataSet.DataSetName = "Student_InformationDataSet"
        Me.Student_InformationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Student_InfoBindingSource
        '
        Me.Student_InfoBindingSource.DataMember = "Student Info"
        Me.Student_InfoBindingSource.DataSource = Me.Student_InformationDataSet
        '
        'Student_InfoTableAdapter
        '
        Me.Student_InfoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Student_InfoTableAdapter = Me.Student_InfoTableAdapter
        Me.TableAdapterManager.UpdateOrder = StudentManagement.Student_InformationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Student_InfoDataGridView
        '
        Me.Student_InfoDataGridView.AutoGenerateColumns = False
        Me.Student_InfoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Student_InfoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.Student_InfoDataGridView.DataSource = Me.Student_InfoBindingSource
        Me.Student_InfoDataGridView.Location = New System.Drawing.Point(467, 72)
        Me.Student_InfoDataGridView.Name = "Student_InfoDataGridView"
        Me.Student_InfoDataGridView.Size = New System.Drawing.Size(740, 448)
        Me.Student_InfoDataGridView.TabIndex = 2
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Index"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Index"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Student ID"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "First Name"
        Me.DataGridViewTextBoxColumn3.HeaderText = "First Name"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Last Name"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Last Name"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Date Of Birth"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Date Of Birth"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Gender"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Gender"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Password"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Password"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'IndexTextBox
        '
        Me.IndexTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Index", True))
        Me.IndexTextBox.Location = New System.Drawing.Point(60, 172)
        Me.IndexTextBox.Name = "IndexTextBox"
        Me.IndexTextBox.Size = New System.Drawing.Size(141, 20)
        Me.IndexTextBox.TabIndex = 3
        '
        'Student_IDTextBox
        '
        Me.Student_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Student ID", True))
        Me.Student_IDTextBox.Location = New System.Drawing.Point(207, 172)
        Me.Student_IDTextBox.Name = "Student_IDTextBox"
        Me.Student_IDTextBox.Size = New System.Drawing.Size(141, 20)
        Me.Student_IDTextBox.TabIndex = 5
        '
        'First_NameTextBox
        '
        Me.First_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "First Name", True))
        Me.First_NameTextBox.Location = New System.Drawing.Point(60, 211)
        Me.First_NameTextBox.Name = "First_NameTextBox"
        Me.First_NameTextBox.Size = New System.Drawing.Size(141, 20)
        Me.First_NameTextBox.TabIndex = 7
        '
        'Last_NameTextBox
        '
        Me.Last_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Last Name", True))
        Me.Last_NameTextBox.Location = New System.Drawing.Point(207, 211)
        Me.Last_NameTextBox.Name = "Last_NameTextBox"
        Me.Last_NameTextBox.Size = New System.Drawing.Size(139, 20)
        Me.Last_NameTextBox.TabIndex = 9
        '
        'Date_Of_BirthTextBox
        '
        Me.Date_Of_BirthTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Date Of Birth", True))
        Me.Date_Of_BirthTextBox.Location = New System.Drawing.Point(60, 247)
        Me.Date_Of_BirthTextBox.Name = "Date_Of_BirthTextBox"
        Me.Date_Of_BirthTextBox.Size = New System.Drawing.Size(141, 20)
        Me.Date_Of_BirthTextBox.TabIndex = 11
        '
        'GenderTextBox
        '
        Me.GenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Gender", True))
        Me.GenderTextBox.Location = New System.Drawing.Point(207, 247)
        Me.GenderTextBox.Name = "GenderTextBox"
        Me.GenderTextBox.Size = New System.Drawing.Size(139, 20)
        Me.GenderTextBox.TabIndex = 13
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_InfoBindingSource, "Password", True))
        Me.PasswordTextBox.Location = New System.Drawing.Point(60, 286)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(141, 20)
        Me.PasswordTextBox.TabIndex = 15
        '
        'btnAddStudent
        '
        Me.btnAddStudent.Location = New System.Drawing.Point(60, 329)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(75, 23)
        Me.btnAddStudent.TabIndex = 16
        Me.btnAddStudent.Text = "Add"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'btnDeleteStudent
        '
        Me.btnDeleteStudent.Location = New System.Drawing.Point(141, 329)
        Me.btnDeleteStudent.Name = "btnDeleteStudent"
        Me.btnDeleteStudent.Size = New System.Drawing.Size(75, 23)
        Me.btnDeleteStudent.TabIndex = 17
        Me.btnDeleteStudent.Text = "Delete"
        Me.btnDeleteStudent.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1227, 647)
        Me.Controls.Add(Me.btnDeleteStudent)
        Me.Controls.Add(Me.btnAddStudent)
        Me.Controls.Add(PasswordLabel)
        Me.Controls.Add(Me.PasswordTextBox)
        Me.Controls.Add(GenderLabel)
        Me.Controls.Add(Me.GenderTextBox)
        Me.Controls.Add(Date_Of_BirthLabel)
        Me.Controls.Add(Me.Date_Of_BirthTextBox)
        Me.Controls.Add(Last_NameLabel)
        Me.Controls.Add(Me.Last_NameTextBox)
        Me.Controls.Add(First_NameLabel)
        Me.Controls.Add(Me.First_NameTextBox)
        Me.Controls.Add(Student_IDLabel)
        Me.Controls.Add(Me.Student_IDTextBox)
        Me.Controls.Add(IndexLabel)
        Me.Controls.Add(Me.IndexTextBox)
        Me.Controls.Add(Me.Student_InfoDataGridView)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Student_InformationDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_InfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_InfoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Student_InformationDataSet As Student_InformationDataSet
    Friend WithEvents Student_InfoBindingSource As BindingSource
    Friend WithEvents Student_InfoTableAdapter As Student_InformationDataSetTableAdapters.Student_InfoTableAdapter
    Friend WithEvents TableAdapterManager As Student_InformationDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_InfoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents IndexTextBox As TextBox
    Friend WithEvents Student_IDTextBox As TextBox
    Friend WithEvents First_NameTextBox As TextBox
    Friend WithEvents Last_NameTextBox As TextBox
    Friend WithEvents Date_Of_BirthTextBox As TextBox
    Friend WithEvents GenderTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents btnDeleteStudent As Button
End Class
