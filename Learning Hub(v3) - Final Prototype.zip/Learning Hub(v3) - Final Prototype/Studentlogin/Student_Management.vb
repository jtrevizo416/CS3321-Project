﻿Public Class Student_Management
    Private Sub Student_infoBindingSource1BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_infoBindingSource1.EndEdit()
        Me.TableAdapterManager1.UpdateAll(Me.Learning_Hub_DBDataSet1)

    End Sub

    Private Sub Student_Management_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet1.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter1.Fill(Me.Learning_Hub_DBDataSet1.student_info)

    End Sub

    Private Sub AddStudent_btn_Click(sender As Object, e As EventArgs) Handles AddStudent_btn.Click
        Me.Student_infoBindingSource1.AddNew() 'Add Student Information to the Database
        Me.Student_infoBindingSource1.EndEdit()
        Me.Student_infoTableAdapter1.Update(Learning_Hub_DBDataSet1.student_info) 'Save Changes to the student info database
        MessageBox.Show("Student has been succesfully added.")
        Student_entry_idTextBox1.Text = "" 'Clear info from the text boxes
        Student_idTextBox1.Text = ""
        First_nameTextBox1.Text = ""
        Last_nameTextBox1.Text = ""
        AddressTextBox1.Text = ""
        Phone_noTextBox1.Text = ""
        GenderTextBox1.Text = ""
        PasswordTextBox1.Text = ""
    End Sub

    Private Sub RemoveStudent_btn_Click(sender As Object, e As EventArgs) Handles RemoveStudent_btn.Click
        Me.Student_infoBindingSource1.RemoveCurrent() 'Remove Student from the database
        Me.Student_infoBindingSource1.EndEdit()
        Me.Student_infoTableAdapter1.Update(Learning_Hub_DBDataSet1.student_info) 'save changes made
        MessageBox.Show("Student has been successfully removed")
    End Sub

    Private Sub AdminControlsLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles AdminControlsLink.LinkClicked
        AdminControls.Show()
        Me.Close()
    End Sub

    Private Sub LogoutLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LogoutLink.LinkClicked
        Login.Show()
        Me.Close()
    End Sub
End Class