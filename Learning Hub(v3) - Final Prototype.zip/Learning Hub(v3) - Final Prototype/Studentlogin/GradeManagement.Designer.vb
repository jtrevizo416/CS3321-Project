﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GradeManagement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Completed_entry_idLabel As System.Windows.Forms.Label
        Dim Student_idLabel As System.Windows.Forms.Label
        Dim Course_idLabel As System.Windows.Forms.Label
        Dim GradeLabel As System.Windows.Forms.Label
        Dim GpaLabel As System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Learning_Hub_DBDataSet = New Studentlogin.Learning_Hub_DBDataSet()
        Me.Student_dataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_dataTableAdapter = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.student_dataTableAdapter()
        Me.TableAdapterManager = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager()
        Me.Student_dataDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Completed_entry_idTextBox = New System.Windows.Forms.TextBox()
        Me.Student_idTextBox = New System.Windows.Forms.TextBox()
        Me.Course_idTextBox = New System.Windows.Forms.TextBox()
        Me.GradeTextBox = New System.Windows.Forms.TextBox()
        Me.GpaTextBox = New System.Windows.Forms.TextBox()
        Me.btnAddGrade = New System.Windows.Forms.Button()
        Me.btnRemoveGrade = New System.Windows.Forms.Button()
        Me.btnGpaCalculator = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CurrentGpaTextBox = New System.Windows.Forms.TextBox()
        Me.NewGradeTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CreditsCurrentGpaTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CreditsForGradeTextBox = New System.Windows.Forms.TextBox()
        Me.NewGpaTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LogoutLink = New System.Windows.Forms.LinkLabel()
        Me.AdminControlsLink = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Completed_entry_idLabel = New System.Windows.Forms.Label()
        Student_idLabel = New System.Windows.Forms.Label()
        Course_idLabel = New System.Windows.Forms.Label()
        GradeLabel = New System.Windows.Forms.Label()
        GpaLabel = New System.Windows.Forms.Label()
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Completed_entry_idLabel
        '
        Completed_entry_idLabel.AutoSize = True
        Completed_entry_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Completed_entry_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Completed_entry_idLabel.Location = New System.Drawing.Point(65, 99)
        Completed_entry_idLabel.Name = "Completed_entry_idLabel"
        Completed_entry_idLabel.Size = New System.Drawing.Size(40, 13)
        Completed_entry_idLabel.TabIndex = 2
        Completed_entry_idLabel.Text = "INDEX"
        '
        'Student_idLabel
        '
        Student_idLabel.AutoSize = True
        Student_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Student_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Student_idLabel.Location = New System.Drawing.Point(241, 99)
        Student_idLabel.Name = "Student_idLabel"
        Student_idLabel.Size = New System.Drawing.Size(73, 13)
        Student_idLabel.TabIndex = 4
        Student_idLabel.Text = "STUDENT ID"
        '
        'Course_idLabel
        '
        Course_idLabel.AutoSize = True
        Course_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Course_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Course_idLabel.Location = New System.Drawing.Point(65, 138)
        Course_idLabel.Name = "Course_idLabel"
        Course_idLabel.Size = New System.Drawing.Size(66, 13)
        Course_idLabel.TabIndex = 6
        Course_idLabel.Text = "COURSE ID"
        '
        'GradeLabel
        '
        GradeLabel.AutoSize = True
        GradeLabel.BackColor = System.Drawing.Color.RoyalBlue
        GradeLabel.ForeColor = System.Drawing.SystemColors.Control
        GradeLabel.Location = New System.Drawing.Point(244, 138)
        GradeLabel.Name = "GradeLabel"
        GradeLabel.Size = New System.Drawing.Size(45, 13)
        GradeLabel.TabIndex = 8
        GradeLabel.Text = "GRADE"
        '
        'GpaLabel
        '
        GpaLabel.AutoSize = True
        GpaLabel.BackColor = System.Drawing.Color.RoyalBlue
        GpaLabel.ForeColor = System.Drawing.SystemColors.Control
        GpaLabel.Location = New System.Drawing.Point(65, 177)
        GpaLabel.Name = "GpaLabel"
        GpaLabel.Size = New System.Drawing.Size(29, 13)
        GpaLabel.TabIndex = 10
        GpaLabel.Text = "GPA"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(402, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(317, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Grade Management"
        '
        'Learning_Hub_DBDataSet
        '
        Me.Learning_Hub_DBDataSet.DataSetName = "Learning_Hub_DBDataSet"
        Me.Learning_Hub_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Student_dataBindingSource
        '
        Me.Student_dataBindingSource.DataMember = "student_data"
        Me.Student_dataBindingSource.DataSource = Me.Learning_Hub_DBDataSet
        '
        'Student_dataTableAdapter
        '
        Me.Student_dataTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.course_infoTableAdapter = Nothing
        Me.TableAdapterManager.student_dataTableAdapter = Me.Student_dataTableAdapter
        Me.TableAdapterManager.student_infoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Student_dataDataGridView
        '
        Me.Student_dataDataGridView.AutoGenerateColumns = False
        Me.Student_dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Student_dataDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.Student_dataDataGridView.DataSource = Me.Student_dataBindingSource
        Me.Student_dataDataGridView.Location = New System.Drawing.Point(543, 83)
        Me.Student_dataDataGridView.Name = "Student_dataDataGridView"
        Me.Student_dataDataGridView.Size = New System.Drawing.Size(544, 392)
        Me.Student_dataDataGridView.TabIndex = 2
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "completed_entry_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "completed_entry_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "student_id"
        Me.DataGridViewTextBoxColumn2.HeaderText = "student_id"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn3.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "grade"
        Me.DataGridViewTextBoxColumn4.HeaderText = "grade"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "gpa"
        Me.DataGridViewTextBoxColumn5.HeaderText = "gpa"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'Completed_entry_idTextBox
        '
        Me.Completed_entry_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_dataBindingSource, "completed_entry_id", True))
        Me.Completed_entry_idTextBox.Location = New System.Drawing.Point(68, 115)
        Me.Completed_entry_idTextBox.Name = "Completed_entry_idTextBox"
        Me.Completed_entry_idTextBox.Size = New System.Drawing.Size(170, 20)
        Me.Completed_entry_idTextBox.TabIndex = 3
        '
        'Student_idTextBox
        '
        Me.Student_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_dataBindingSource, "student_id", True))
        Me.Student_idTextBox.Location = New System.Drawing.Point(244, 115)
        Me.Student_idTextBox.Name = "Student_idTextBox"
        Me.Student_idTextBox.Size = New System.Drawing.Size(170, 20)
        Me.Student_idTextBox.TabIndex = 5
        '
        'Course_idTextBox
        '
        Me.Course_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_dataBindingSource, "course_id", True))
        Me.Course_idTextBox.Location = New System.Drawing.Point(68, 154)
        Me.Course_idTextBox.Name = "Course_idTextBox"
        Me.Course_idTextBox.Size = New System.Drawing.Size(170, 20)
        Me.Course_idTextBox.TabIndex = 7
        '
        'GradeTextBox
        '
        Me.GradeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_dataBindingSource, "grade", True))
        Me.GradeTextBox.Location = New System.Drawing.Point(244, 154)
        Me.GradeTextBox.Name = "GradeTextBox"
        Me.GradeTextBox.Size = New System.Drawing.Size(170, 20)
        Me.GradeTextBox.TabIndex = 9
        '
        'GpaTextBox
        '
        Me.GpaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_dataBindingSource, "gpa", True))
        Me.GpaTextBox.Location = New System.Drawing.Point(68, 193)
        Me.GpaTextBox.Name = "GpaTextBox"
        Me.GpaTextBox.Size = New System.Drawing.Size(170, 20)
        Me.GpaTextBox.TabIndex = 11
        '
        'btnAddGrade
        '
        Me.btnAddGrade.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddGrade.Location = New System.Drawing.Point(68, 219)
        Me.btnAddGrade.Name = "btnAddGrade"
        Me.btnAddGrade.Size = New System.Drawing.Size(75, 23)
        Me.btnAddGrade.TabIndex = 12
        Me.btnAddGrade.Text = "Add"
        Me.btnAddGrade.UseVisualStyleBackColor = True
        '
        'btnRemoveGrade
        '
        Me.btnRemoveGrade.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRemoveGrade.Location = New System.Drawing.Point(149, 219)
        Me.btnRemoveGrade.Name = "btnRemoveGrade"
        Me.btnRemoveGrade.Size = New System.Drawing.Size(75, 23)
        Me.btnRemoveGrade.TabIndex = 13
        Me.btnRemoveGrade.Text = "Remove"
        Me.btnRemoveGrade.UseVisualStyleBackColor = True
        '
        'btnGpaCalculator
        '
        Me.btnGpaCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGpaCalculator.Location = New System.Drawing.Point(68, 400)
        Me.btnGpaCalculator.Name = "btnGpaCalculator"
        Me.btnGpaCalculator.Size = New System.Drawing.Size(79, 26)
        Me.btnGpaCalculator.TabIndex = 27
        Me.btnGpaCalculator.Text = "Calculate Gpa"
        Me.btnGpaCalculator.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(65, 279)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "CURRENT GPA"
        '
        'CurrentGpaTextBox
        '
        Me.CurrentGpaTextBox.Location = New System.Drawing.Point(68, 295)
        Me.CurrentGpaTextBox.Name = "CurrentGpaTextBox"
        Me.CurrentGpaTextBox.Size = New System.Drawing.Size(170, 20)
        Me.CurrentGpaTextBox.TabIndex = 25
        '
        'NewGradeTextBox
        '
        Me.NewGradeTextBox.Location = New System.Drawing.Point(68, 335)
        Me.NewGradeTextBox.Name = "NewGradeTextBox"
        Me.NewGradeTextBox.Size = New System.Drawing.Size(170, 20)
        Me.NewGradeTextBox.TabIndex = 28
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(65, 319)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "NEW GRADE"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(241, 279)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(256, 13)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "AMOUNT CREDITS CURRENT GPA IS BASED ON"
        '
        'CreditsCurrentGpaTextBox
        '
        Me.CreditsCurrentGpaTextBox.Location = New System.Drawing.Point(244, 295)
        Me.CreditsCurrentGpaTextBox.Name = "CreditsCurrentGpaTextBox"
        Me.CreditsCurrentGpaTextBox.Size = New System.Drawing.Size(170, 20)
        Me.CreditsCurrentGpaTextBox.TabIndex = 30
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label5.ForeColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(241, 319)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(216, 13)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "AMOUNT OF CREDITS FOR NEW GRADE"
        '
        'CreditsForGradeTextBox
        '
        Me.CreditsForGradeTextBox.Location = New System.Drawing.Point(244, 335)
        Me.CreditsForGradeTextBox.Name = "CreditsForGradeTextBox"
        Me.CreditsForGradeTextBox.Size = New System.Drawing.Size(170, 20)
        Me.CreditsForGradeTextBox.TabIndex = 32
        '
        'NewGpaTextBox
        '
        Me.NewGpaTextBox.Location = New System.Drawing.Point(68, 374)
        Me.NewGpaTextBox.Name = "NewGpaTextBox"
        Me.NewGpaTextBox.ReadOnly = True
        Me.NewGpaTextBox.Size = New System.Drawing.Size(170, 20)
        Me.NewGpaTextBox.TabIndex = 34
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label6.ForeColor = System.Drawing.SystemColors.Control
        Me.Label6.Location = New System.Drawing.Point(65, 358)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 13)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "NEW GPA"
        '
        'LogoutLink
        '
        Me.LogoutLink.AutoSize = True
        Me.LogoutLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutLink.Location = New System.Drawing.Point(1084, 18)
        Me.LogoutLink.Name = "LogoutLink"
        Me.LogoutLink.Size = New System.Drawing.Size(60, 18)
        Me.LogoutLink.TabIndex = 37
        Me.LogoutLink.TabStop = True
        Me.LogoutLink.Text = "Logout"
        '
        'AdminControlsLink
        '
        Me.AdminControlsLink.AutoSize = True
        Me.AdminControlsLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdminControlsLink.Location = New System.Drawing.Point(22, 13)
        Me.AdminControlsLink.Name = "AdminControlsLink"
        Me.AdminControlsLink.Size = New System.Drawing.Size(139, 18)
        Me.AdminControlsLink.TabIndex = 36
        Me.AdminControlsLink.TabStop = True
        Me.AdminControlsLink.Text = "< Admin Controls"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox1.Location = New System.Drawing.Point(43, 68)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(464, 186)
        Me.PictureBox1.TabIndex = 38
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox2.Location = New System.Drawing.Point(43, 260)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(464, 200)
        Me.PictureBox2.TabIndex = 39
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox3.Location = New System.Drawing.Point(513, 68)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(599, 418)
        Me.PictureBox3.TabIndex = 40
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Studentlogin.My.Resources.Resources.download
        Me.PictureBox4.Location = New System.Drawing.Point(205, -1)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(137, 63)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 41
        Me.PictureBox4.TabStop = False
        '
        'GradeManagement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1156, 487)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.LogoutLink)
        Me.Controls.Add(Me.AdminControlsLink)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.NewGpaTextBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.CreditsForGradeTextBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CreditsCurrentGpaTextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.NewGradeTextBox)
        Me.Controls.Add(Me.btnGpaCalculator)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CurrentGpaTextBox)
        Me.Controls.Add(Me.btnRemoveGrade)
        Me.Controls.Add(Me.btnAddGrade)
        Me.Controls.Add(GpaLabel)
        Me.Controls.Add(Me.GpaTextBox)
        Me.Controls.Add(GradeLabel)
        Me.Controls.Add(Me.GradeTextBox)
        Me.Controls.Add(Course_idLabel)
        Me.Controls.Add(Me.Course_idTextBox)
        Me.Controls.Add(Student_idLabel)
        Me.Controls.Add(Me.Student_idTextBox)
        Me.Controls.Add(Completed_entry_idLabel)
        Me.Controls.Add(Me.Completed_entry_idTextBox)
        Me.Controls.Add(Me.Student_dataDataGridView)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox3)
        Me.Name = "GradeManagement"
        Me.Text = "GradeManagement"
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Learning_Hub_DBDataSet As Learning_Hub_DBDataSet
    Friend WithEvents Student_dataBindingSource As BindingSource
    Friend WithEvents Student_dataTableAdapter As Learning_Hub_DBDataSetTableAdapters.student_dataTableAdapter
    Friend WithEvents TableAdapterManager As Learning_Hub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_dataDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents Completed_entry_idTextBox As TextBox
    Friend WithEvents Student_idTextBox As TextBox
    Friend WithEvents Course_idTextBox As TextBox
    Friend WithEvents GradeTextBox As TextBox
    Friend WithEvents GpaTextBox As TextBox
    Friend WithEvents btnAddGrade As Button
    Friend WithEvents btnRemoveGrade As Button
    Friend WithEvents btnGpaCalculator As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents CurrentGpaTextBox As TextBox
    Friend WithEvents NewGradeTextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CreditsCurrentGpaTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents CreditsForGradeTextBox As TextBox
    Friend WithEvents NewGpaTextBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents LogoutLink As LinkLabel
    Friend WithEvents AdminControlsLink As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
End Class
