﻿

Public Class Form1

    Private Sub Student_infoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_infoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Learning_Hub_DBDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.student_data' table. You can move, or remove it, as needed.
        Me.Student_dataTableAdapter.Fill(Me.Learning_Hub_DBDataSet.student_data)
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.course_info' table. You can move, or remove it, as needed.
        Me.Course_infoTableAdapter.Fill(Me.Learning_Hub_DBDataSet.course_info)
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter.Fill(Me.Learning_Hub_DBDataSet.student_info)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click 'add class button
        Me.Student_dataBindingSource.AddNew() 'Add Student Information to the Database

        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(Learning_Hub_DBDataSet.student_data) 'Save Changes to the student info database
        MessageBox.Show("Course has been succesfully added.")
        'Clear info from the text boxes
        Course_idTextBox.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Student_dataBindingSource.RemoveCurrent()
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(Learning_Hub_DBDataSet.student_data)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Student_dataBindingSource.RemoveCurrent()
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(Learning_Hub_DBDataSet.student_data)
    End Sub


    Private Sub LogoutLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LogoutLink.LinkClicked
        Login.Show()
        Me.Close()
    End Sub
End Class