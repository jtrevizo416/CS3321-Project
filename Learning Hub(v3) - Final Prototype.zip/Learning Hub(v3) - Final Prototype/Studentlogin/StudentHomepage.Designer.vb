﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Student_entry_idLabel = New System.Windows.Forms.Label()
        Me.Student_idLabel = New System.Windows.Forms.Label()
        Me.First_nameLabel = New System.Windows.Forms.Label()
        Me.Last_nameLabel = New System.Windows.Forms.Label()
        Me.GenderLabel = New System.Windows.Forms.Label()
        Me.AddressLabel = New System.Windows.Forms.Label()
        Me.Phone_noLabel = New System.Windows.Forms.Label()
        Me.Course_idLabel = New System.Windows.Forms.Label()
        Me.SubjectLabel = New System.Windows.Forms.Label()
        Me.Course_noLabel = New System.Windows.Forms.Label()
        Me.Learning_Hub_DBDataSet = New Studentlogin.Learning_Hub_DBDataSet()
        Me.Student_infoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_infoTableAdapter = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.student_infoTableAdapter()
        Me.TableAdapterManager = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager()
        Me.Course_infoTableAdapter = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.course_infoTableAdapter()
        Me.Student_dataTableAdapter = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.student_dataTableAdapter()
        Me.Student_entry_idTextBox = New System.Windows.Forms.TextBox()
        Me.Student_idTextBox = New System.Windows.Forms.TextBox()
        Me.First_nameTextBox = New System.Windows.Forms.TextBox()
        Me.Last_nameTextBox = New System.Windows.Forms.TextBox()
        Me.GenderTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.Phone_noTextBox = New System.Windows.Forms.TextBox()
        Me.Course_infoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Course_idTextBox = New System.Windows.Forms.TextBox()
        Me.SubjectTextBox = New System.Windows.Forms.TextBox()
        Me.Course_noTextBox = New System.Windows.Forms.TextBox()
        Me.Course_infoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Student_dataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_dataDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.LogoutLink = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_infoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Student_entry_idLabel
        '
        Me.Student_entry_idLabel.AutoSize = True
        Me.Student_entry_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Student_entry_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Student_entry_idLabel.Location = New System.Drawing.Point(33, 92)
        Me.Student_entry_idLabel.Name = "Student_entry_idLabel"
        Me.Student_entry_idLabel.Size = New System.Drawing.Size(40, 13)
        Me.Student_entry_idLabel.TabIndex = 1
        Me.Student_entry_idLabel.Text = "INDEX"
        '
        'Student_idLabel
        '
        Me.Student_idLabel.AutoSize = True
        Me.Student_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Student_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Student_idLabel.Location = New System.Drawing.Point(33, 118)
        Me.Student_idLabel.Name = "Student_idLabel"
        Me.Student_idLabel.Size = New System.Drawing.Size(73, 13)
        Me.Student_idLabel.TabIndex = 3
        Me.Student_idLabel.Text = "STUDENT ID"
        '
        'First_nameLabel
        '
        Me.First_nameLabel.AutoSize = True
        Me.First_nameLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.First_nameLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.First_nameLabel.Location = New System.Drawing.Point(33, 144)
        Me.First_nameLabel.Name = "First_nameLabel"
        Me.First_nameLabel.Size = New System.Drawing.Size(72, 13)
        Me.First_nameLabel.TabIndex = 5
        Me.First_nameLabel.Text = "FIRST NAME"
        '
        'Last_nameLabel
        '
        Me.Last_nameLabel.AutoSize = True
        Me.Last_nameLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Last_nameLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Last_nameLabel.Location = New System.Drawing.Point(33, 170)
        Me.Last_nameLabel.Name = "Last_nameLabel"
        Me.Last_nameLabel.Size = New System.Drawing.Size(68, 13)
        Me.Last_nameLabel.TabIndex = 7
        Me.Last_nameLabel.Text = "LAST NAME"
        '
        'GenderLabel
        '
        Me.GenderLabel.AutoSize = True
        Me.GenderLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.GenderLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.GenderLabel.Location = New System.Drawing.Point(33, 196)
        Me.GenderLabel.Name = "GenderLabel"
        Me.GenderLabel.Size = New System.Drawing.Size(53, 13)
        Me.GenderLabel.TabIndex = 9
        Me.GenderLabel.Text = "GENDER"
        '
        'AddressLabel
        '
        Me.AddressLabel.AutoSize = True
        Me.AddressLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.AddressLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.AddressLabel.Location = New System.Drawing.Point(33, 222)
        Me.AddressLabel.Name = "AddressLabel"
        Me.AddressLabel.Size = New System.Drawing.Size(59, 13)
        Me.AddressLabel.TabIndex = 11
        Me.AddressLabel.Text = "ADDRESS"
        '
        'Phone_noLabel
        '
        Me.Phone_noLabel.AutoSize = True
        Me.Phone_noLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Phone_noLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Phone_noLabel.Location = New System.Drawing.Point(33, 248)
        Me.Phone_noLabel.Name = "Phone_noLabel"
        Me.Phone_noLabel.Size = New System.Drawing.Size(73, 13)
        Me.Phone_noLabel.TabIndex = 13
        Me.Phone_noLabel.Text = "PHONE NUM"
        '
        'Course_idLabel
        '
        Me.Course_idLabel.AutoSize = True
        Me.Course_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Course_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Course_idLabel.Location = New System.Drawing.Point(43, 400)
        Me.Course_idLabel.Name = "Course_idLabel"
        Me.Course_idLabel.Size = New System.Drawing.Size(66, 13)
        Me.Course_idLabel.TabIndex = 15
        Me.Course_idLabel.Text = "COURSE ID"
        '
        'SubjectLabel
        '
        Me.SubjectLabel.AutoSize = True
        Me.SubjectLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.SubjectLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.SubjectLabel.Location = New System.Drawing.Point(43, 426)
        Me.SubjectLabel.Name = "SubjectLabel"
        Me.SubjectLabel.Size = New System.Drawing.Size(55, 13)
        Me.SubjectLabel.TabIndex = 17
        Me.SubjectLabel.Text = "SUBJECT"
        '
        'Course_noLabel
        '
        Me.Course_noLabel.AutoSize = True
        Me.Course_noLabel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Course_noLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.Course_noLabel.Location = New System.Drawing.Point(43, 452)
        Me.Course_noLabel.Name = "Course_noLabel"
        Me.Course_noLabel.Size = New System.Drawing.Size(80, 13)
        Me.Course_noLabel.TabIndex = 19
        Me.Course_noLabel.Text = "COURSE NUM"
        '
        'Learning_Hub_DBDataSet
        '
        Me.Learning_Hub_DBDataSet.DataSetName = "Learning_Hub_DBDataSet"
        Me.Learning_Hub_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Student_infoBindingSource
        '
        Me.Student_infoBindingSource.DataMember = "student_info"
        Me.Student_infoBindingSource.DataSource = Me.Learning_Hub_DBDataSet
        '
        'Student_infoTableAdapter
        '
        Me.Student_infoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.course_infoTableAdapter = Me.Course_infoTableAdapter
        Me.TableAdapterManager.student_dataTableAdapter = Me.Student_dataTableAdapter
        Me.TableAdapterManager.student_infoTableAdapter = Me.Student_infoTableAdapter
        Me.TableAdapterManager.UpdateOrder = Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Course_infoTableAdapter
        '
        Me.Course_infoTableAdapter.ClearBeforeFill = True
        '
        'Student_dataTableAdapter
        '
        Me.Student_dataTableAdapter.ClearBeforeFill = True
        '
        'Student_entry_idTextBox
        '
        Me.Student_entry_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "student_entry_id", True))
        Me.Student_entry_idTextBox.Location = New System.Drawing.Point(121, 89)
        Me.Student_entry_idTextBox.Name = "Student_entry_idTextBox"
        Me.Student_entry_idTextBox.ReadOnly = True
        Me.Student_entry_idTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_entry_idTextBox.TabIndex = 2
        '
        'Student_idTextBox
        '
        Me.Student_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "student_id", True))
        Me.Student_idTextBox.Location = New System.Drawing.Point(121, 115)
        Me.Student_idTextBox.Name = "Student_idTextBox"
        Me.Student_idTextBox.ReadOnly = True
        Me.Student_idTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_idTextBox.TabIndex = 4
        '
        'First_nameTextBox
        '
        Me.First_nameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "first_name", True))
        Me.First_nameTextBox.Location = New System.Drawing.Point(121, 141)
        Me.First_nameTextBox.Name = "First_nameTextBox"
        Me.First_nameTextBox.ReadOnly = True
        Me.First_nameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.First_nameTextBox.TabIndex = 6
        '
        'Last_nameTextBox
        '
        Me.Last_nameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "last_name", True))
        Me.Last_nameTextBox.Location = New System.Drawing.Point(121, 167)
        Me.Last_nameTextBox.Name = "Last_nameTextBox"
        Me.Last_nameTextBox.ReadOnly = True
        Me.Last_nameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Last_nameTextBox.TabIndex = 8
        '
        'GenderTextBox
        '
        Me.GenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "Gender", True))
        Me.GenderTextBox.Location = New System.Drawing.Point(121, 193)
        Me.GenderTextBox.Name = "GenderTextBox"
        Me.GenderTextBox.ReadOnly = True
        Me.GenderTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GenderTextBox.TabIndex = 10
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "Address", True))
        Me.AddressTextBox.Location = New System.Drawing.Point(121, 219)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.ReadOnly = True
        Me.AddressTextBox.Size = New System.Drawing.Size(100, 20)
        Me.AddressTextBox.TabIndex = 12
        '
        'Phone_noTextBox
        '
        Me.Phone_noTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "phone_no", True))
        Me.Phone_noTextBox.Location = New System.Drawing.Point(121, 245)
        Me.Phone_noTextBox.Name = "Phone_noTextBox"
        Me.Phone_noTextBox.ReadOnly = True
        Me.Phone_noTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Phone_noTextBox.TabIndex = 14
        '
        'Course_infoBindingSource
        '
        Me.Course_infoBindingSource.DataMember = "course_info"
        Me.Course_infoBindingSource.DataSource = Me.Learning_Hub_DBDataSet
        '
        'Course_idTextBox
        '
        Me.Course_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "course_id", True))
        Me.Course_idTextBox.Location = New System.Drawing.Point(121, 397)
        Me.Course_idTextBox.Name = "Course_idTextBox"
        Me.Course_idTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Course_idTextBox.TabIndex = 16
        '
        'SubjectTextBox
        '
        Me.SubjectTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "subject", True))
        Me.SubjectTextBox.Location = New System.Drawing.Point(121, 423)
        Me.SubjectTextBox.Name = "SubjectTextBox"
        Me.SubjectTextBox.Size = New System.Drawing.Size(200, 20)
        Me.SubjectTextBox.TabIndex = 18
        '
        'Course_noTextBox
        '
        Me.Course_noTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "course_no", True))
        Me.Course_noTextBox.Location = New System.Drawing.Point(121, 449)
        Me.Course_noTextBox.Name = "Course_noTextBox"
        Me.Course_noTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Course_noTextBox.TabIndex = 20
        '
        'Course_infoDataGridView
        '
        Me.Course_infoDataGridView.AutoGenerateColumns = False
        Me.Course_infoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Course_infoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9})
        Me.Course_infoDataGridView.DataSource = Me.Course_infoBindingSource
        Me.Course_infoDataGridView.Location = New System.Drawing.Point(438, 364)
        Me.Course_infoDataGridView.Name = "Course_infoDataGridView"
        Me.Course_infoDataGridView.Size = New System.Drawing.Size(949, 310)
        Me.Course_infoDataGridView.TabIndex = 29
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "subject"
        Me.DataGridViewTextBoxColumn2.HeaderText = "subject"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "course_no"
        Me.DataGridViewTextBoxColumn3.HeaderText = "course_no"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "course_desc"
        Me.DataGridViewTextBoxColumn4.HeaderText = "course_desc"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "class_time"
        Me.DataGridViewTextBoxColumn5.HeaderText = "class_time"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "class_date"
        Me.DataGridViewTextBoxColumn6.HeaderText = "class_date"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "max_students"
        Me.DataGridViewTextBoxColumn7.HeaderText = "max_students"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Start Date"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Start Date"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "End Date"
        Me.DataGridViewTextBoxColumn9.HeaderText = "End Date"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(33, 279)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "OVERALL GPA"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(121, 279)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 31
        '
        'Student_dataBindingSource
        '
        Me.Student_dataBindingSource.DataMember = "student_data"
        Me.Student_dataBindingSource.DataSource = Me.Learning_Hub_DBDataSet
        '
        'Student_dataDataGridView
        '
        Me.Student_dataDataGridView.AutoGenerateColumns = False
        Me.Student_dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Student_dataDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14})
        Me.Student_dataDataGridView.DataSource = Me.Student_dataBindingSource
        Me.Student_dataDataGridView.Location = New System.Drawing.Point(438, 89)
        Me.Student_dataDataGridView.Name = "Student_dataDataGridView"
        Me.Student_dataDataGridView.Size = New System.Drawing.Size(545, 220)
        Me.Student_dataDataGridView.TabIndex = 31
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "completed_entry_id"
        Me.DataGridViewTextBoxColumn10.HeaderText = "completed_entry_id"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "student_id"
        Me.DataGridViewTextBoxColumn11.HeaderText = "student_id"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn12.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "grade"
        Me.DataGridViewTextBoxColumn13.HeaderText = "grade"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "gpa"
        Me.DataGridViewTextBoxColumn14.HeaderText = "gpa"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Location = New System.Drawing.Point(36, 308)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 32
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Location = New System.Drawing.Point(46, 528)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 33
        Me.Button2.Text = "Add Class"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Location = New System.Drawing.Point(168, 528)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 34
        Me.Button3.Text = "Delete"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Location = New System.Drawing.Point(46, 576)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 35
        Me.Button4.Text = "Refresh"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Location = New System.Drawing.Point(168, 576)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 36
        Me.Button5.Text = "Save"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'LogoutLink
        '
        Me.LogoutLink.AutoSize = True
        Me.LogoutLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutLink.Location = New System.Drawing.Point(12, 26)
        Me.LogoutLink.Name = "LogoutLink"
        Me.LogoutLink.Size = New System.Drawing.Size(60, 18)
        Me.LogoutLink.TabIndex = 37
        Me.LogoutLink.TabStop = True
        Me.LogoutLink.Text = "Logout"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(468, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(330, 39)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Student Homepage"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox1.Location = New System.Drawing.Point(404, 71)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(627, 260)
        Me.PictureBox1.TabIndex = 39
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox2.Location = New System.Drawing.Point(12, 71)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(331, 277)
        Me.PictureBox2.TabIndex = 40
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox3.Location = New System.Drawing.Point(404, 337)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(1019, 350)
        Me.PictureBox3.TabIndex = 41
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox4.Location = New System.Drawing.Point(12, 364)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(331, 323)
        Me.PictureBox4.TabIndex = 42
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Studentlogin.My.Resources.Resources._40567_2
        Me.PictureBox5.Location = New System.Drawing.Point(1082, 71)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(305, 260)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 43
        Me.PictureBox5.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1409, 686)
        Me.Controls.Add(Me.Course_noTextBox)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LogoutLink)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Student_dataDataGridView)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Course_infoDataGridView)
        Me.Controls.Add(Me.Course_idLabel)
        Me.Controls.Add(Me.Course_idTextBox)
        Me.Controls.Add(Me.SubjectLabel)
        Me.Controls.Add(Me.SubjectTextBox)
        Me.Controls.Add(Me.Course_noLabel)
        Me.Controls.Add(Me.Student_entry_idLabel)
        Me.Controls.Add(Me.Student_entry_idTextBox)
        Me.Controls.Add(Me.Student_idLabel)
        Me.Controls.Add(Me.Student_idTextBox)
        Me.Controls.Add(Me.First_nameLabel)
        Me.Controls.Add(Me.First_nameTextBox)
        Me.Controls.Add(Me.Last_nameLabel)
        Me.Controls.Add(Me.Last_nameTextBox)
        Me.Controls.Add(Me.GenderLabel)
        Me.Controls.Add(Me.GenderTextBox)
        Me.Controls.Add(Me.AddressLabel)
        Me.Controls.Add(Me.AddressTextBox)
        Me.Controls.Add(Me.Phone_noLabel)
        Me.Controls.Add(Me.Phone_noTextBox)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox4)
        Me.Name = "Form1"
        Me.Text = "Student Homepage"
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_infoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Learning_Hub_DBDataSet As Learning_Hub_DBDataSet
    Friend WithEvents Student_infoBindingSource As BindingSource
    Friend WithEvents Student_infoTableAdapter As Learning_Hub_DBDataSetTableAdapters.student_infoTableAdapter
    Friend WithEvents TableAdapterManager As Learning_Hub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_entry_idTextBox As TextBox
    Friend WithEvents Student_idTextBox As TextBox
    Friend WithEvents First_nameTextBox As TextBox
    Friend WithEvents Last_nameTextBox As TextBox
    Friend WithEvents GenderTextBox As TextBox
    Friend WithEvents AddressTextBox As TextBox
    Friend WithEvents Phone_noTextBox As TextBox
    Friend WithEvents Course_infoTableAdapter As Learning_Hub_DBDataSetTableAdapters.course_infoTableAdapter
    Friend WithEvents Course_infoBindingSource As BindingSource
    Friend WithEvents Student_dataTableAdapter As Learning_Hub_DBDataSetTableAdapters.student_dataTableAdapter
    Friend WithEvents Course_idTextBox As TextBox
    Friend WithEvents SubjectTextBox As TextBox
    Friend WithEvents Course_noTextBox As TextBox
    Friend WithEvents Course_infoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Student_dataBindingSource As BindingSource
    Friend WithEvents Student_dataDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Student_entry_idLabel As Label
    Friend WithEvents Student_idLabel As Label
    Friend WithEvents First_nameLabel As Label
    Friend WithEvents Last_nameLabel As Label
    Friend WithEvents GenderLabel As Label
    Friend WithEvents AddressLabel As Label
    Friend WithEvents Phone_noLabel As Label
    Friend WithEvents Course_idLabel As Label
    Friend WithEvents SubjectLabel As Label
    Friend WithEvents Course_noLabel As Label
    Friend WithEvents LogoutLink As LinkLabel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
End Class
