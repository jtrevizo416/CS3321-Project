﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Management
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Student_entry_idLabel As System.Windows.Forms.Label
        Dim Student_idLabel As System.Windows.Forms.Label
        Dim First_nameLabel As System.Windows.Forms.Label
        Dim Last_nameLabel As System.Windows.Forms.Label
        Dim GenderLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim Phone_noLabel As System.Windows.Forms.Label
        Dim PasswordLabel As System.Windows.Forms.Label
        Me.Learning_Hub_DBDataSet1 = New Studentlogin.Learning_Hub_DBDataSet()
        Me.Student_infoBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_infoTableAdapter1 = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.student_infoTableAdapter()
        Me.TableAdapterManager1 = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager()
        Me.Student_infoDataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Student_entry_idTextBox1 = New System.Windows.Forms.TextBox()
        Me.Student_idTextBox1 = New System.Windows.Forms.TextBox()
        Me.First_nameTextBox1 = New System.Windows.Forms.TextBox()
        Me.Last_nameTextBox1 = New System.Windows.Forms.TextBox()
        Me.GenderTextBox1 = New System.Windows.Forms.TextBox()
        Me.AddressTextBox1 = New System.Windows.Forms.TextBox()
        Me.Phone_noTextBox1 = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox1 = New System.Windows.Forms.TextBox()
        Me.AddStudent_btn = New System.Windows.Forms.Button()
        Me.RemoveStudent_btn = New System.Windows.Forms.Button()
        Me.AdminControlsLink = New System.Windows.Forms.LinkLabel()
        Me.LogoutLink = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Student_entry_idLabel = New System.Windows.Forms.Label()
        Student_idLabel = New System.Windows.Forms.Label()
        First_nameLabel = New System.Windows.Forms.Label()
        Last_nameLabel = New System.Windows.Forms.Label()
        GenderLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        Phone_noLabel = New System.Windows.Forms.Label()
        PasswordLabel = New System.Windows.Forms.Label()
        CType(Me.Learning_Hub_DBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_infoBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_infoDataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Student_entry_idLabel
        '
        Student_entry_idLabel.AutoSize = True
        Student_entry_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Student_entry_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Student_entry_idLabel.Location = New System.Drawing.Point(119, 204)
        Student_entry_idLabel.Name = "Student_entry_idLabel"
        Student_entry_idLabel.Size = New System.Drawing.Size(40, 13)
        Student_entry_idLabel.TabIndex = 2
        Student_entry_idLabel.Text = "INDEX"
        '
        'Student_idLabel
        '
        Student_idLabel.AutoSize = True
        Student_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Student_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Student_idLabel.Location = New System.Drawing.Point(289, 204)
        Student_idLabel.Name = "Student_idLabel"
        Student_idLabel.Size = New System.Drawing.Size(73, 13)
        Student_idLabel.TabIndex = 4
        Student_idLabel.Text = "STUDENT ID"
        '
        'First_nameLabel
        '
        First_nameLabel.AutoSize = True
        First_nameLabel.BackColor = System.Drawing.Color.RoyalBlue
        First_nameLabel.ForeColor = System.Drawing.SystemColors.Control
        First_nameLabel.Location = New System.Drawing.Point(119, 243)
        First_nameLabel.Name = "First_nameLabel"
        First_nameLabel.Size = New System.Drawing.Size(72, 13)
        First_nameLabel.TabIndex = 6
        First_nameLabel.Text = "FIRST NAME"
        '
        'Last_nameLabel
        '
        Last_nameLabel.AutoSize = True
        Last_nameLabel.BackColor = System.Drawing.Color.RoyalBlue
        Last_nameLabel.ForeColor = System.Drawing.SystemColors.Control
        Last_nameLabel.Location = New System.Drawing.Point(290, 243)
        Last_nameLabel.Name = "Last_nameLabel"
        Last_nameLabel.Size = New System.Drawing.Size(68, 13)
        Last_nameLabel.TabIndex = 8
        Last_nameLabel.Text = "LAST NAME"
        '
        'GenderLabel
        '
        GenderLabel.AutoSize = True
        GenderLabel.BackColor = System.Drawing.Color.RoyalBlue
        GenderLabel.ForeColor = System.Drawing.SystemColors.Control
        GenderLabel.Location = New System.Drawing.Point(119, 282)
        GenderLabel.Name = "GenderLabel"
        GenderLabel.Size = New System.Drawing.Size(53, 13)
        GenderLabel.TabIndex = 10
        GenderLabel.Text = "GENDER"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.BackColor = System.Drawing.Color.RoyalBlue
        AddressLabel.ForeColor = System.Drawing.SystemColors.Control
        AddressLabel.Location = New System.Drawing.Point(290, 282)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(59, 13)
        AddressLabel.TabIndex = 12
        AddressLabel.Text = "ADDRESS"
        '
        'Phone_noLabel
        '
        Phone_noLabel.AutoSize = True
        Phone_noLabel.BackColor = System.Drawing.Color.RoyalBlue
        Phone_noLabel.ForeColor = System.Drawing.SystemColors.Control
        Phone_noLabel.Location = New System.Drawing.Point(119, 321)
        Phone_noLabel.Name = "Phone_noLabel"
        Phone_noLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Phone_noLabel.Size = New System.Drawing.Size(95, 13)
        Phone_noLabel.TabIndex = 14
        Phone_noLabel.Text = "PHONE NUMBER"
        '
        'PasswordLabel
        '
        PasswordLabel.AutoSize = True
        PasswordLabel.BackColor = System.Drawing.Color.RoyalBlue
        PasswordLabel.ForeColor = System.Drawing.SystemColors.Control
        PasswordLabel.Location = New System.Drawing.Point(290, 321)
        PasswordLabel.Name = "PasswordLabel"
        PasswordLabel.Size = New System.Drawing.Size(70, 13)
        PasswordLabel.TabIndex = 16
        PasswordLabel.Text = "PASSWORD"
        '
        'Learning_Hub_DBDataSet1
        '
        Me.Learning_Hub_DBDataSet1.DataSetName = "Learning_Hub_DBDataSet"
        Me.Learning_Hub_DBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Student_infoBindingSource1
        '
        Me.Student_infoBindingSource1.DataMember = "student_info"
        Me.Student_infoBindingSource1.DataSource = Me.Learning_Hub_DBDataSet1
        '
        'Student_infoTableAdapter1
        '
        Me.Student_infoTableAdapter1.ClearBeforeFill = True
        '
        'TableAdapterManager1
        '
        Me.TableAdapterManager1.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager1.course_infoTableAdapter = Nothing
        Me.TableAdapterManager1.student_dataTableAdapter = Nothing
        Me.TableAdapterManager1.student_infoTableAdapter = Me.Student_infoTableAdapter1
        Me.TableAdapterManager1.UpdateOrder = Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Student_infoDataGridView1
        '
        Me.Student_infoDataGridView1.AutoGenerateColumns = False
        Me.Student_infoDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Student_infoDataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16})
        Me.Student_infoDataGridView1.DataSource = Me.Student_infoBindingSource1
        Me.Student_infoDataGridView1.Location = New System.Drawing.Point(634, 86)
        Me.Student_infoDataGridView1.Name = "Student_infoDataGridView1"
        Me.Student_infoDataGridView1.Size = New System.Drawing.Size(838, 514)
        Me.Student_infoDataGridView1.TabIndex = 1
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "student_entry_id"
        Me.DataGridViewTextBoxColumn9.HeaderText = "student_entry_id"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "student_id"
        Me.DataGridViewTextBoxColumn10.HeaderText = "student_id"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "first_name"
        Me.DataGridViewTextBoxColumn11.HeaderText = "first_name"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "last_name"
        Me.DataGridViewTextBoxColumn12.HeaderText = "last_name"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "Gender"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Gender"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "Address"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Address"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "phone_no"
        Me.DataGridViewTextBoxColumn15.HeaderText = "phone_no"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "Password"
        Me.DataGridViewTextBoxColumn16.HeaderText = "Password"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(496, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(365, 39)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Student Management"
        '
        'Student_entry_idTextBox1
        '
        Me.Student_entry_idTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "student_entry_id", True))
        Me.Student_entry_idTextBox1.Location = New System.Drawing.Point(122, 220)
        Me.Student_entry_idTextBox1.Name = "Student_entry_idTextBox1"
        Me.Student_entry_idTextBox1.Size = New System.Drawing.Size(164, 20)
        Me.Student_entry_idTextBox1.TabIndex = 3
        '
        'Student_idTextBox1
        '
        Me.Student_idTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "student_id", True))
        Me.Student_idTextBox1.Location = New System.Drawing.Point(292, 220)
        Me.Student_idTextBox1.Name = "Student_idTextBox1"
        Me.Student_idTextBox1.Size = New System.Drawing.Size(164, 20)
        Me.Student_idTextBox1.TabIndex = 5
        '
        'First_nameTextBox1
        '
        Me.First_nameTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "first_name", True))
        Me.First_nameTextBox1.Location = New System.Drawing.Point(122, 259)
        Me.First_nameTextBox1.Name = "First_nameTextBox1"
        Me.First_nameTextBox1.Size = New System.Drawing.Size(164, 20)
        Me.First_nameTextBox1.TabIndex = 7
        '
        'Last_nameTextBox1
        '
        Me.Last_nameTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "last_name", True))
        Me.Last_nameTextBox1.Location = New System.Drawing.Point(293, 259)
        Me.Last_nameTextBox1.Name = "Last_nameTextBox1"
        Me.Last_nameTextBox1.Size = New System.Drawing.Size(163, 20)
        Me.Last_nameTextBox1.TabIndex = 9
        '
        'GenderTextBox1
        '
        Me.GenderTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "Gender", True))
        Me.GenderTextBox1.Location = New System.Drawing.Point(122, 298)
        Me.GenderTextBox1.Name = "GenderTextBox1"
        Me.GenderTextBox1.Size = New System.Drawing.Size(164, 20)
        Me.GenderTextBox1.TabIndex = 11
        '
        'AddressTextBox1
        '
        Me.AddressTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "Address", True))
        Me.AddressTextBox1.Location = New System.Drawing.Point(293, 298)
        Me.AddressTextBox1.Name = "AddressTextBox1"
        Me.AddressTextBox1.Size = New System.Drawing.Size(163, 20)
        Me.AddressTextBox1.TabIndex = 13
        '
        'Phone_noTextBox1
        '
        Me.Phone_noTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "phone_no", True))
        Me.Phone_noTextBox1.Location = New System.Drawing.Point(122, 337)
        Me.Phone_noTextBox1.Name = "Phone_noTextBox1"
        Me.Phone_noTextBox1.Size = New System.Drawing.Size(164, 20)
        Me.Phone_noTextBox1.TabIndex = 15
        '
        'PasswordTextBox1
        '
        Me.PasswordTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource1, "Password", True))
        Me.PasswordTextBox1.Location = New System.Drawing.Point(293, 337)
        Me.PasswordTextBox1.Name = "PasswordTextBox1"
        Me.PasswordTextBox1.Size = New System.Drawing.Size(163, 20)
        Me.PasswordTextBox1.TabIndex = 17
        '
        'AddStudent_btn
        '
        Me.AddStudent_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.AddStudent_btn.Location = New System.Drawing.Point(122, 363)
        Me.AddStudent_btn.Name = "AddStudent_btn"
        Me.AddStudent_btn.Size = New System.Drawing.Size(75, 23)
        Me.AddStudent_btn.TabIndex = 18
        Me.AddStudent_btn.Text = "Add"
        Me.AddStudent_btn.UseVisualStyleBackColor = True
        '
        'RemoveStudent_btn
        '
        Me.RemoveStudent_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RemoveStudent_btn.Location = New System.Drawing.Point(203, 363)
        Me.RemoveStudent_btn.Name = "RemoveStudent_btn"
        Me.RemoveStudent_btn.Size = New System.Drawing.Size(75, 23)
        Me.RemoveStudent_btn.TabIndex = 19
        Me.RemoveStudent_btn.Text = "Remove"
        Me.RemoveStudent_btn.UseVisualStyleBackColor = True
        '
        'AdminControlsLink
        '
        Me.AdminControlsLink.AutoSize = True
        Me.AdminControlsLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdminControlsLink.Location = New System.Drawing.Point(20, 26)
        Me.AdminControlsLink.Name = "AdminControlsLink"
        Me.AdminControlsLink.Size = New System.Drawing.Size(139, 18)
        Me.AdminControlsLink.TabIndex = 20
        Me.AdminControlsLink.TabStop = True
        Me.AdminControlsLink.Text = "< Admin Controls"
        '
        'LogoutLink
        '
        Me.LogoutLink.AutoSize = True
        Me.LogoutLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutLink.Location = New System.Drawing.Point(1412, 30)
        Me.LogoutLink.Name = "LogoutLink"
        Me.LogoutLink.Size = New System.Drawing.Size(60, 18)
        Me.LogoutLink.TabIndex = 21
        Me.LogoutLink.TabStop = True
        Me.LogoutLink.Text = "Logout"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox1.Location = New System.Drawing.Point(95, 166)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(394, 272)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox2.Location = New System.Drawing.Point(600, 65)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(889, 560)
        Me.PictureBox2.TabIndex = 23
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Studentlogin.My.Resources.Resources._40567_2
        Me.PictureBox3.Location = New System.Drawing.Point(95, 460)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(394, 188)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 24
        Me.PictureBox3.TabStop = False
        '
        'Student_Management
        '
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1484, 660)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.LogoutLink)
        Me.Controls.Add(Me.AdminControlsLink)
        Me.Controls.Add(Me.RemoveStudent_btn)
        Me.Controls.Add(Me.AddStudent_btn)
        Me.Controls.Add(PasswordLabel)
        Me.Controls.Add(Me.PasswordTextBox1)
        Me.Controls.Add(Phone_noLabel)
        Me.Controls.Add(Me.Phone_noTextBox1)
        Me.Controls.Add(AddressLabel)
        Me.Controls.Add(Me.AddressTextBox1)
        Me.Controls.Add(GenderLabel)
        Me.Controls.Add(Me.GenderTextBox1)
        Me.Controls.Add(Last_nameLabel)
        Me.Controls.Add(Me.Last_nameTextBox1)
        Me.Controls.Add(First_nameLabel)
        Me.Controls.Add(Me.First_nameTextBox1)
        Me.Controls.Add(Student_idLabel)
        Me.Controls.Add(Me.Student_idTextBox1)
        Me.Controls.Add(Student_entry_idLabel)
        Me.Controls.Add(Me.Student_entry_idTextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Student_infoDataGridView1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "Student_Management"
        CType(Me.Learning_Hub_DBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_infoBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_infoDataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnRemoveStudent As Button
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Learning_Hub_DBDataSet As Learning_Hub_DBDataSet
    Friend WithEvents Student_infoBindingSource As BindingSource
    Friend WithEvents Student_infoTableAdapter As Learning_Hub_DBDataSetTableAdapters.student_infoTableAdapter
    Friend WithEvents TableAdapterManager As Learning_Hub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_infoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents Student_entry_idTextBox As TextBox
    Friend WithEvents Student_idTextBox As TextBox
    Friend WithEvents First_nameTextBox As TextBox
    Friend WithEvents Last_nameTextBox As TextBox
    Friend WithEvents GenderTextBox As TextBox
    Friend WithEvents AddressTextBox As TextBox
    Friend WithEvents Phone_noTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents Learning_Hub_DBDataSet1 As Learning_Hub_DBDataSet
    Friend WithEvents Student_infoBindingSource1 As BindingSource
    Friend WithEvents Student_infoTableAdapter1 As Learning_Hub_DBDataSetTableAdapters.student_infoTableAdapter
    Friend WithEvents TableAdapterManager1 As Learning_Hub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_infoDataGridView1 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents Student_entry_idTextBox1 As TextBox
    Friend WithEvents Student_idTextBox1 As TextBox
    Friend WithEvents First_nameTextBox1 As TextBox
    Friend WithEvents Last_nameTextBox1 As TextBox
    Friend WithEvents GenderTextBox1 As TextBox
    Friend WithEvents AddressTextBox1 As TextBox
    Friend WithEvents Phone_noTextBox1 As TextBox
    Friend WithEvents PasswordTextBox1 As TextBox
    Friend WithEvents AddStudent_btn As Button
    Friend WithEvents RemoveStudent_btn As Button
    Friend WithEvents AdminControlsLink As LinkLabel
    Friend WithEvents LogoutLink As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
End Class
