﻿Public Class CourseManagement
    Private Sub Course_infoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Course_infoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Learning_Hub_DBDataSet)
    End Sub

    Private Sub CourseManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.course_info' table. You can move, or remove it, as needed.
        Me.Course_infoTableAdapter.Fill(Me.Learning_Hub_DBDataSet.course_info)

    End Sub

    Private Sub btnAddCourse_Click(sender As Object, e As EventArgs) Handles btnAddCourse.Click
        Me.Course_infoBindingSource.AddNew() 'Add  new course information to the database
        Me.Course_infoBindingSource.EndEdit()
        Me.Course_infoTableAdapter.Update(Learning_Hub_DBDataSet) 'save changes made
        MessageBox.Show("Course has been successfully added")
        Course_idTextBox.Text = "" 'clear information on the textboxes
        SubjectTextBox.Text = ""
        Course_noTextBox.Text = ""
        Course_descTextBox.Text = ""
        Class_timeTextBox.Text = ""
        Class_dateTextBox.Text = ""
        Max_studentsTextBox.Text = ""
        Start_DateDateTimePicker.ResetText()
        End_DateDateTimePicker.ResetText()
    End Sub

    Private Sub btnRemoveCourse_Click(sender As Object, e As EventArgs) Handles btnRemoveCourse.Click
        Me.Course_infoBindingSource.RemoveCurrent() 'remove course from the database
        Me.Course_infoBindingSource.EndEdit()
        Me.Course_infoTableAdapter.Update(Learning_Hub_DBDataSet) 'save changes made
        MessageBox.Show("Course has been successfully removed")
    End Sub

    Private Sub AdminControlsLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles AdminControlsLink.LinkClicked
        AdminControls.Show()
        Me.Close()
    End Sub

    Private Sub LogoutLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LogoutLink.LinkClicked
        AdminControls.Show()
        Me.Close()
    End Sub


End Class