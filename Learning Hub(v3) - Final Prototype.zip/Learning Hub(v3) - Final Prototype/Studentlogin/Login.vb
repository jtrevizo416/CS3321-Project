﻿Imports System.Data.OleDb
Imports StudentHomepage

Public Class Login
    Private Sub Student_InfoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_InfoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me._Student_Information_v3_DataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_Student_Information_v3_DataSet.Student_Info' table. You can move, or remove it, as needed.
        ' Me.Student_InfoTableAdapter.Fill(Me._Student_Information_v3_DataSet.Student_Info)
        'Dim builder As New OleDbConnectionStringBuilder

        'builder.Provider = "Microsoft.Jet.OLEDB.4.0"
        'builder.DataSource = "|DataDirectory|\Learning Hub DB.mbd"

        'Dim connString As String = builder.ConnectionString

        'Dim connection As New OleDbConnection(connString)
        'connection.Open()



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "admin" And txtPassword.Text = "password" Then 'Admin Login
            Call adminlogin()
        Else
            Dim conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Learning Hub DB.mdb")
            conn.Open()
            Dim cmdlog As OleDbCommand = New OleDbCommand("SELECT * FROM [student_info] WHERE [student_id] = '" & txtUsername.Text & "' AND [Password] = '" & txtPassword.Text & "'", conn)
            Dim drlog As OleDbDataReader = cmdlog.ExecuteReader
            If (drlog.Read() = True) Then
                MsgBox("Successful Login")
                Call userlogin()
                'TO DO Load Student Home Page Form
            Else
                MsgBox("Incorect Username or Password")
            End If
        End If



        'If txtUsername.Text = "admin" And txtPassword.Text = "password" Then 'Admin Login
        '    Call adminlogin()
        'ElseIf txtUsername.Text = "" And txtPassword.Text = "password" Then 'Student Login
        '    Student_InfoBindingSource.Filter = "(Convert(Student_ID, System.String) LIKE" & txtUsername.Text & "')" &
        '    Call userlogin()
        'Else
        '    MsgBox("Incorrect username and Password!")
        'End If
    End Sub
    Private Sub adminlogin()
        MsgBox("Welcome Admin!")
        AdminControls.Show()
        Me.Close()
    End Sub
    Private Sub userlogin()
        MsgBox("Welcome Student!")
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub Student_InfoBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_InfoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me._Student_Information_v3_DataSet)

    End Sub


End Class
