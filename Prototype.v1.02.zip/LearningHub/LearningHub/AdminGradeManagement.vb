﻿Public Class AdminGradeManagement
    Private Sub Student_dataBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Student_dataBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Student_dataBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.LearningHub_DBDataSet)

    End Sub

    Private Sub AdminGradeManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LearningHub_DBDataSet.student_data' table. You can move, or remove it, as needed.
        Me.Student_dataTableAdapter.Fill(Me.LearningHub_DBDataSet.student_data)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Student_dataBindingSource.AddNew() 'Add Student Information to the Database
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(LearningHub_DBDataSet.student_data) 'Save Changes to the student info database
        MessageBox.Show("Student has been succesfully added.")
        'Clear info from the text boxes
        Completed_entry_idTextBox.Text = ""
        Student_idTextBox.Text = ""
        Course_idTextBox.Text = ""
        GradeTextBox.Text = ""
        GpaTextBox.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Student_dataBindingSource.RemoveCurrent() 'Remove Student from the database
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(LearningHub_DBDataSet.student_data) 'save changes made
        MessageBox.Show("Student has been successfully removed")
    End Sub
End Class