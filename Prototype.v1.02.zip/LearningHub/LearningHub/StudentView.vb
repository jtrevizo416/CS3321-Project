﻿Public Class StudentView
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LearningHub_DBDataSet.course_info' table. You can move, or remove it, as needed.
        Me.Course_infoTableAdapter.Fill(Me.LearningHub_DBDataSet.course_info)
        'TODO: This line of code loads data into the 'LearningHub_DBDataSet.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter.Fill(Me.LearningHub_DBDataSet.student_info)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'Delete
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Close()
    End Sub
End Class
