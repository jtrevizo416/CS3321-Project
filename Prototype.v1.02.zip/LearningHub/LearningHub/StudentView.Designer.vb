﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class StudentView
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Student_idLabel As System.Windows.Forms.Label
        Dim First_nameLabel As System.Windows.Forms.Label
        Dim Last_nameLabel As System.Windows.Forms.Label
        Dim GenderLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim Phone_noLabel As System.Windows.Forms.Label
        Dim PasswordLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StudentView))
        Me.LearningHub_DBDataSet = New LearningHub.LearningHub_DBDataSet()
        Me.Student_dataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_dataTableAdapter = New LearningHub.LearningHub_DBDataSetTableAdapters.student_dataTableAdapter()
        Me.TableAdapterManager = New LearningHub.LearningHub_DBDataSetTableAdapters.TableAdapterManager()
        Me.Student_dataBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Student_dataBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Student_infoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Student_infoTableAdapter = New LearningHub.LearningHub_DBDataSetTableAdapters.student_infoTableAdapter()
        Me.Student_idTextBox = New System.Windows.Forms.TextBox()
        Me.First_nameTextBox = New System.Windows.Forms.TextBox()
        Me.Last_nameTextBox = New System.Windows.Forms.TextBox()
        Me.GenderTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.Phone_noTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.Student_dataDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Course_infoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Course_infoTableAdapter = New LearningHub.LearningHub_DBDataSetTableAdapters.course_infoTableAdapter()
        Me.Course_infoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Student_idLabel = New System.Windows.Forms.Label()
        First_nameLabel = New System.Windows.Forms.Label()
        Last_nameLabel = New System.Windows.Forms.Label()
        GenderLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        Phone_noLabel = New System.Windows.Forms.Label()
        PasswordLabel = New System.Windows.Forms.Label()
        CType(Me.LearningHub_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Student_dataBindingNavigator.SuspendLayout()
        CType(Me.Student_infoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Student_idLabel
        '
        Student_idLabel.AutoSize = True
        Student_idLabel.Location = New System.Drawing.Point(45, 64)
        Student_idLabel.Name = "Student_idLabel"
        Student_idLabel.Size = New System.Drawing.Size(56, 13)
        Student_idLabel.TabIndex = 3
        Student_idLabel.Text = "student id:"
        '
        'First_nameLabel
        '
        First_nameLabel.AutoSize = True
        First_nameLabel.Location = New System.Drawing.Point(45, 90)
        First_nameLabel.Name = "First_nameLabel"
        First_nameLabel.Size = New System.Drawing.Size(55, 13)
        First_nameLabel.TabIndex = 5
        First_nameLabel.Text = "first name:"
        '
        'Last_nameLabel
        '
        Last_nameLabel.AutoSize = True
        Last_nameLabel.Location = New System.Drawing.Point(45, 116)
        Last_nameLabel.Name = "Last_nameLabel"
        Last_nameLabel.Size = New System.Drawing.Size(55, 13)
        Last_nameLabel.TabIndex = 7
        Last_nameLabel.Text = "last name:"
        '
        'GenderLabel
        '
        GenderLabel.AutoSize = True
        GenderLabel.Location = New System.Drawing.Point(45, 142)
        GenderLabel.Name = "GenderLabel"
        GenderLabel.Size = New System.Drawing.Size(45, 13)
        GenderLabel.TabIndex = 9
        GenderLabel.Text = "Gender:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.Location = New System.Drawing.Point(45, 168)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(48, 13)
        AddressLabel.TabIndex = 11
        AddressLabel.Text = "Address:"
        '
        'Phone_noLabel
        '
        Phone_noLabel.AutoSize = True
        Phone_noLabel.Location = New System.Drawing.Point(45, 194)
        Phone_noLabel.Name = "Phone_noLabel"
        Phone_noLabel.Size = New System.Drawing.Size(55, 13)
        Phone_noLabel.TabIndex = 13
        Phone_noLabel.Text = "phone no:"
        '
        'PasswordLabel
        '
        PasswordLabel.AutoSize = True
        PasswordLabel.Location = New System.Drawing.Point(45, 220)
        PasswordLabel.Name = "PasswordLabel"
        PasswordLabel.Size = New System.Drawing.Size(56, 13)
        PasswordLabel.TabIndex = 15
        PasswordLabel.Text = "Password:"
        '
        'LearningHub_DBDataSet
        '
        Me.LearningHub_DBDataSet.DataSetName = "LearningHub_DBDataSet"
        Me.LearningHub_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Student_dataBindingSource
        '
        Me.Student_dataBindingSource.DataMember = "student_data"
        Me.Student_dataBindingSource.DataSource = Me.LearningHub_DBDataSet
        '
        'Student_dataTableAdapter
        '
        Me.Student_dataTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.course_infoTableAdapter = Nothing
        Me.TableAdapterManager.student_dataTableAdapter = Me.Student_dataTableAdapter
        Me.TableAdapterManager.student_infoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = LearningHub.LearningHub_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Student_dataBindingNavigator
        '
        Me.Student_dataBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.Student_dataBindingNavigator.BindingSource = Me.Student_dataBindingSource
        Me.Student_dataBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Student_dataBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.Student_dataBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.Student_dataBindingNavigatorSaveItem})
        Me.Student_dataBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Student_dataBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Student_dataBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Student_dataBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Student_dataBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Student_dataBindingNavigator.Name = "Student_dataBindingNavigator"
        Me.Student_dataBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Student_dataBindingNavigator.Size = New System.Drawing.Size(999, 25)
        Me.Student_dataBindingNavigator.TabIndex = 0
        Me.Student_dataBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Student_dataBindingNavigatorSaveItem
        '
        Me.Student_dataBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Student_dataBindingNavigatorSaveItem.Image = CType(resources.GetObject("Student_dataBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.Student_dataBindingNavigatorSaveItem.Name = "Student_dataBindingNavigatorSaveItem"
        Me.Student_dataBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.Student_dataBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Student_infoBindingSource
        '
        Me.Student_infoBindingSource.DataMember = "student_info"
        Me.Student_infoBindingSource.DataSource = Me.LearningHub_DBDataSet
        '
        'Student_infoTableAdapter
        '
        Me.Student_infoTableAdapter.ClearBeforeFill = True
        '
        'Student_idTextBox
        '
        Me.Student_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "student_id", True))
        Me.Student_idTextBox.Location = New System.Drawing.Point(133, 61)
        Me.Student_idTextBox.Name = "Student_idTextBox"
        Me.Student_idTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_idTextBox.TabIndex = 4
        '
        'First_nameTextBox
        '
        Me.First_nameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "first_name", True))
        Me.First_nameTextBox.Location = New System.Drawing.Point(133, 87)
        Me.First_nameTextBox.Name = "First_nameTextBox"
        Me.First_nameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.First_nameTextBox.TabIndex = 6
        '
        'Last_nameTextBox
        '
        Me.Last_nameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "last_name", True))
        Me.Last_nameTextBox.Location = New System.Drawing.Point(133, 113)
        Me.Last_nameTextBox.Name = "Last_nameTextBox"
        Me.Last_nameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Last_nameTextBox.TabIndex = 8
        '
        'GenderTextBox
        '
        Me.GenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "Gender", True))
        Me.GenderTextBox.Location = New System.Drawing.Point(133, 139)
        Me.GenderTextBox.Name = "GenderTextBox"
        Me.GenderTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GenderTextBox.TabIndex = 10
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "Address", True))
        Me.AddressTextBox.Location = New System.Drawing.Point(133, 165)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(100, 20)
        Me.AddressTextBox.TabIndex = 12
        '
        'Phone_noTextBox
        '
        Me.Phone_noTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "phone_no", True))
        Me.Phone_noTextBox.Location = New System.Drawing.Point(133, 191)
        Me.Phone_noTextBox.Name = "Phone_noTextBox"
        Me.Phone_noTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Phone_noTextBox.TabIndex = 14
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Student_infoBindingSource, "Password", True))
        Me.PasswordTextBox.Location = New System.Drawing.Point(133, 217)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(100, 20)
        Me.PasswordTextBox.TabIndex = 16
        '
        'Student_dataDataGridView
        '
        Me.Student_dataDataGridView.AutoGenerateColumns = False
        Me.Student_dataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Student_dataDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.Student_dataDataGridView.DataSource = Me.Student_dataBindingSource
        Me.Student_dataDataGridView.Location = New System.Drawing.Point(285, 61)
        Me.Student_dataDataGridView.Name = "Student_dataDataGridView"
        Me.Student_dataDataGridView.Size = New System.Drawing.Size(543, 242)
        Me.Student_dataDataGridView.TabIndex = 16
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "completed_entry_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "completed_entry_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "student_id"
        Me.DataGridViewTextBoxColumn2.HeaderText = "student_id"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn3.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "grade"
        Me.DataGridViewTextBoxColumn4.HeaderText = "grade"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "gpa"
        Me.DataGridViewTextBoxColumn5.HeaderText = "gpa"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(27, 426)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Add Class"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(45, 372)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 13)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Course ID to Regester:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(48, 388)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 19
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(27, 455)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "Refresh"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(108, 455)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = "Save "
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(108, 426)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 22
        Me.Button4.Text = "Delete"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(48, 290)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 23
        Me.Button5.Text = "Exit"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Course_infoBindingSource
        '
        Me.Course_infoBindingSource.DataMember = "course_info"
        Me.Course_infoBindingSource.DataSource = Me.LearningHub_DBDataSet
        '
        'Course_infoTableAdapter
        '
        Me.Course_infoTableAdapter.ClearBeforeFill = True
        '
        'Course_infoDataGridView
        '
        Me.Course_infoDataGridView.AutoGenerateColumns = False
        Me.Course_infoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Course_infoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12})
        Me.Course_infoDataGridView.DataSource = Me.Course_infoBindingSource
        Me.Course_infoDataGridView.Location = New System.Drawing.Point(215, 356)
        Me.Course_infoDataGridView.Name = "Course_infoDataGridView"
        Me.Course_infoDataGridView.Size = New System.Drawing.Size(745, 263)
        Me.Course_infoDataGridView.TabIndex = 23
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn6.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "subject"
        Me.DataGridViewTextBoxColumn7.HeaderText = "subject"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "course_no"
        Me.DataGridViewTextBoxColumn8.HeaderText = "course_no"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "course_desc"
        Me.DataGridViewTextBoxColumn9.HeaderText = "course_desc"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "class_time"
        Me.DataGridViewTextBoxColumn10.HeaderText = "class_time"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "class_date"
        Me.DataGridViewTextBoxColumn11.HeaderText = "class_date"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "max_students"
        Me.DataGridViewTextBoxColumn12.HeaderText = "max_students"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(282, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(119, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Completed Coursework:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(45, 247)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Overall GPA"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(133, 244)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 26
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(215, 337)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Available Courses:"
        '
        'StudentView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 631)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Course_infoDataGridView)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Student_dataDataGridView)
        Me.Controls.Add(Student_idLabel)
        Me.Controls.Add(Me.Student_idTextBox)
        Me.Controls.Add(First_nameLabel)
        Me.Controls.Add(Me.First_nameTextBox)
        Me.Controls.Add(Last_nameLabel)
        Me.Controls.Add(Me.Last_nameTextBox)
        Me.Controls.Add(GenderLabel)
        Me.Controls.Add(Me.GenderTextBox)
        Me.Controls.Add(AddressLabel)
        Me.Controls.Add(Me.AddressTextBox)
        Me.Controls.Add(Phone_noLabel)
        Me.Controls.Add(Me.Phone_noTextBox)
        Me.Controls.Add(PasswordLabel)
        Me.Controls.Add(Me.PasswordTextBox)
        Me.Controls.Add(Me.Student_dataBindingNavigator)
        Me.Name = "StudentView"
        Me.Text = "Form1"
        CType(Me.LearningHub_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Student_dataBindingNavigator.ResumeLayout(False)
        Me.Student_dataBindingNavigator.PerformLayout()
        CType(Me.Student_infoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Student_dataDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LearningHub_DBDataSet As LearningHub_DBDataSet
    Friend WithEvents Student_dataBindingSource As BindingSource
    Friend WithEvents Student_dataTableAdapter As LearningHub_DBDataSetTableAdapters.student_dataTableAdapter
    Friend WithEvents TableAdapterManager As LearningHub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_dataBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents Student_dataBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents Student_infoBindingSource As BindingSource
    Friend WithEvents Student_infoTableAdapter As LearningHub_DBDataSetTableAdapters.student_infoTableAdapter
    Friend WithEvents Student_idTextBox As TextBox
    Friend WithEvents First_nameTextBox As TextBox
    Friend WithEvents Last_nameTextBox As TextBox
    Friend WithEvents GenderTextBox As TextBox
    Friend WithEvents AddressTextBox As TextBox
    Friend WithEvents Phone_noTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents Student_dataDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Course_infoBindingSource As BindingSource
    Friend WithEvents Course_infoTableAdapter As LearningHub_DBDataSetTableAdapters.course_infoTableAdapter
    Friend WithEvents Course_infoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label4 As Label
End Class
