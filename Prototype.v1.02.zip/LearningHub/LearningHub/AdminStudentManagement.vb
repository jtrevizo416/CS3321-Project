﻿Public Class AdminStudentManagement
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Student_infoBindingSource.AddNew() 'Add Student Information to the Database
        Me.Student_infoBindingSource.EndEdit()
        Me.Student_infoTableAdapter.Update(LearningHub_DBDataSet.student_info) 'Save Changes to the student info database
        MessageBox.Show("Student has been succesfully added.")
        'Clear info from the text boxes
        Student_entry_idTextBox.Text = ""
        Student_idTextBox.Text = ""
        First_nameTextBox.Text = ""
        Last_nameTextBox.Text = ""
        GenderTextBox.Text = ""
        PasswordTextBox.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Student_infoBindingSource.RemoveCurrent() 'Remove Student from the database
        Me.Student_infoBindingSource.EndEdit()
        Me.Student_infoTableAdapter.Update(LearningHub_DBDataSet.student_info) 'save changes made
        MessageBox.Show("Student has been successfully removed")
    End Sub

    Private Sub AdminManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LearningHub_DBDataSet.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter.Fill(Me.LearningHub_DBDataSet.student_info)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
End Class