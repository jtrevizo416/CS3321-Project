﻿Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim oForm As New StudentInfo

        oForm.Show()
        Me.Hide()
    End Sub

End Class
