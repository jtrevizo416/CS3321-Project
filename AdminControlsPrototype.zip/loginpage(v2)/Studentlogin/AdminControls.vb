﻿

Public Class AdminControls
    Private Sub btnStudentManagement_Click(sender As Object, e As EventArgs) Handles btnStudentManagement.Click
        Student_Management.Show()
        Me.Close()
    End Sub

    Private Sub btnCourseManagement_Click(sender As Object, e As EventArgs) Handles btnCourseManagement.Click
        CourseManagement.Show()
        Me.Close()
    End Sub

    Private Sub btnGradeManagement_Click(sender As Object, e As EventArgs) Handles btnGradeManagement.Click
        GradeManagement.Show()
        Me.Close()
    End Sub
End Class