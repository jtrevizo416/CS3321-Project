﻿Public Class Student_Management
    Private Sub Student_infoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_infoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Learning_Hub_DBDataSet)

    End Sub

    Private Sub Student_Management_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter.Fill(Me.Learning_Hub_DBDataSet.student_info)

    End Sub

    Private Sub AddStudent_btn_Click(sender As Object, e As EventArgs) Handles AddStudent_btn.Click
        Me.Student_infoBindingSource.AddNew() 'Add Student Information to the Database
        Me.Student_infoBindingSource.EndEdit()
        Me.Student_infoTableAdapter.Update(Learning_Hub_DBDataSet.student_info) 'Save Changes to the student info database
        MessageBox.Show("Student has been succesfully added.")
        Student_entry_idTextBox.Text = "" 'Clear info from the text boxes
        Student_idTextBox.Text = ""
        First_nameTextBox.Text = ""
        Last_nameTextBox.Text = ""
        AddressTextBox.Text = ""
        Phone_noTextBox.Text = ""
        GenderTextBox.Text = ""
        PasswordTextBox.Text = ""
    End Sub

    Private Sub RemoveStudent_btn_Click(sender As Object, e As EventArgs) Handles RemoveStudent_btn.Click
        Me.Student_infoBindingSource.RemoveCurrent() 'Remove Student from the database
        Me.Student_infoBindingSource.EndEdit()
        Me.Student_infoTableAdapter.Update(Learning_Hub_DBDataSet.student_info) 'save changes made
        MessageBox.Show("Student has been successfully removed")
    End Sub

    Private Sub Student_infoBindingSource1BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_infoBindingSource1.EndEdit()
        Me.TableAdapterManager1.UpdateAll(Me.Learning_Hub_DBDataSet1)

    End Sub

    Private Sub Student_Management_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet1.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter1.Fill(Me.Learning_Hub_DBDataSet1.student_info)

    End Sub


End Class