﻿Partial Class Learning_Hub_DBDataSet
End Class

Namespace Learning_Hub_DBDataSetTableAdapters
    Partial Public Class course_infoTableAdapter
    End Class
End Namespace
