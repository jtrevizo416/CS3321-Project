﻿Public Class Student_Data
    Private Sub Student_infoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Student_infoBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Student_infoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Learning_Hub_DBDataSet1)

    End Sub

    Private Sub Student_Data_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet1.student_data' table. You can move, or remove it, as needed.
        Me.Student_dataTableAdapter.Fill(Me.Learning_Hub_DBDataSet1.student_data)
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet1.student_info' table. You can move, or remove it, as needed.
        Me.Student_infoTableAdapter.Fill(Me.Learning_Hub_DBDataSet1.student_info)

    End Sub

    Private Sub Student_idTextBox_TextChanged(sender As Object, e As EventArgs) Handles Student_idTextBox.TextChanged

    End Sub
End Class
