﻿Public Class GradeManagement
    Private Sub Student_dataBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Student_dataBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Learning_Hub_DBDataSet)

    End Sub

    Private Sub GradeManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Learning_Hub_DBDataSet.student_data' table. You can move, or remove it, as needed.
        Me.Student_dataTableAdapter.Fill(Me.Learning_Hub_DBDataSet.student_data)

    End Sub

    Private Sub btnAddGrade_Click(sender As Object, e As EventArgs) Handles btnAddGrade.Click
        Me.Student_dataBindingSource.AddNew() 'Add New Grade
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(Learning_Hub_DBDataSet) 'Save changes
        MessageBox.Show("Grades successfully added")
        Completed_entry_idTextBox.Text = "" 'clear information
        Student_idTextBox.Text = ""
        Course_idTextBox.Text = ""
        GradeTextBox.Text = ""
        GpaTextBox.Text = ""
    End Sub

    Private Sub btnRemoveGrade_Click(sender As Object, e As EventArgs) Handles btnRemoveGrade.Click
        Me.Student_dataBindingSource.RemoveCurrent() 'Remove Grade
        Me.Student_dataBindingSource.EndEdit()
        Me.Student_dataTableAdapter.Update(Learning_Hub_DBDataSet) 'save changes
        MessageBox.Show("Grade has been successfully removed")
    End Sub

    Private Sub GpaTextBox_TextChanged(sender As Object, e As EventArgs) Handles GpaTextBox.TextChanged
        'Calculate Gpa for student
        Dim A As Double = 4.0
        Dim B As Double = 3.0
        Dim C As Double = 2.0
        Dim D As Double = 1.0
        Dim F As Double = 0.0
    End Sub

    Private Sub btnGpaCalculator_Click(sender As Object, e As EventArgs) Handles btnGpaCalculator.Click
        Dim A As Double = 4.0
        Dim B As Double = 3.0
        Dim C As Double = 2.0
        Dim D As Double = 1.0
        Dim F As Double = 0.0
        CurrentGpaTextBox.Text = GpaTextBox.Text
        Dim CurrentGpa As Double = Val(GpaTextBox.Text)
        Dim NewgradeDouble As Double

        If NewGradeTextBox.Text = "A" Then
            NewgradeDouble = A
        ElseIf NewGradeTextBox.Text = "B" Then
            NewgradeDouble = B
        ElseIf NewGradeTextBox.Text = "C" Then
            NewgradeDouble = C
        ElseIf NewGradeTextBox.Text = "D" Then
            NewgradeDouble = D
        ElseIf NewGradeTextBox.Text = "F" Then
            NewgradeDouble = F
        End If

        Dim CreditsCurrent As Double = Val(CreditsCurrentGpaTextBox.Text)
        Dim NewCredits As Double = Val(CreditsForGradeTextBox.Text)

        'Calculate Gpa
        Dim CurrentVal As Double = CurrentGpa * CreditsCurrent 'Multiplty Current Gpa with amount of credits
        Dim NewVal As Double = NewgradeDouble * NewCredits 'Multiply new grade with the amount of credits
        Dim NewGpaScore As Double = (CurrentVal + NewVal) / (CreditsCurrent + NewCredits) 'Add the 2 values and divide by 2
        NewGpaTextBox.Text = CStr(NewGpaScore)
    End Sub

    Private Sub AdminControlsLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles AdminControlsLink.LinkClicked
        AdminControls.Show()
        Me.Close()
    End Sub

    Private Sub LogoutLink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LogoutLink.LinkClicked
        Login.Show()
        Me.Close()
    End Sub
End Class