﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CourseManagement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Course_idLabel As System.Windows.Forms.Label
        Dim SubjectLabel As System.Windows.Forms.Label
        Dim Course_noLabel As System.Windows.Forms.Label
        Dim Course_descLabel As System.Windows.Forms.Label
        Dim Class_timeLabel As System.Windows.Forms.Label
        Dim Class_dateLabel As System.Windows.Forms.Label
        Dim Max_studentsLabel As System.Windows.Forms.Label
        Dim Start_DateLabel As System.Windows.Forms.Label
        Dim End_DateLabel As System.Windows.Forms.Label
        Me.Learning_Hub_DBDataSet = New Studentlogin.Learning_Hub_DBDataSet()
        Me.Course_infoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Course_infoTableAdapter = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.course_infoTableAdapter()
        Me.TableAdapterManager = New Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager()
        Me.Course_infoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Course_idTextBox = New System.Windows.Forms.TextBox()
        Me.SubjectTextBox = New System.Windows.Forms.TextBox()
        Me.Course_noTextBox = New System.Windows.Forms.TextBox()
        Me.Course_descTextBox = New System.Windows.Forms.TextBox()
        Me.Class_timeTextBox = New System.Windows.Forms.TextBox()
        Me.Class_dateTextBox = New System.Windows.Forms.TextBox()
        Me.Max_studentsTextBox = New System.Windows.Forms.TextBox()
        Me.Start_DateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.End_DateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        Me.btnRemoveCourse = New System.Windows.Forms.Button()
        Me.LogoutLink = New System.Windows.Forms.LinkLabel()
        Me.AdminControlsLink = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Course_idLabel = New System.Windows.Forms.Label()
        SubjectLabel = New System.Windows.Forms.Label()
        Course_noLabel = New System.Windows.Forms.Label()
        Course_descLabel = New System.Windows.Forms.Label()
        Class_timeLabel = New System.Windows.Forms.Label()
        Class_dateLabel = New System.Windows.Forms.Label()
        Max_studentsLabel = New System.Windows.Forms.Label()
        Start_DateLabel = New System.Windows.Forms.Label()
        End_DateLabel = New System.Windows.Forms.Label()
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Course_idLabel
        '
        Course_idLabel.AutoSize = True
        Course_idLabel.BackColor = System.Drawing.Color.RoyalBlue
        Course_idLabel.ForeColor = System.Drawing.SystemColors.Control
        Course_idLabel.Location = New System.Drawing.Point(17, 66)
        Course_idLabel.Name = "Course_idLabel"
        Course_idLabel.Size = New System.Drawing.Size(66, 13)
        Course_idLabel.TabIndex = 2
        Course_idLabel.Text = "COURSE ID"
        '
        'SubjectLabel
        '
        SubjectLabel.AutoSize = True
        SubjectLabel.BackColor = System.Drawing.Color.RoyalBlue
        SubjectLabel.ForeColor = System.Drawing.SystemColors.Control
        SubjectLabel.Location = New System.Drawing.Point(233, 66)
        SubjectLabel.Name = "SubjectLabel"
        SubjectLabel.Size = New System.Drawing.Size(55, 13)
        SubjectLabel.TabIndex = 4
        SubjectLabel.Text = "SUBJECT"
        '
        'Course_noLabel
        '
        Course_noLabel.AutoSize = True
        Course_noLabel.BackColor = System.Drawing.Color.RoyalBlue
        Course_noLabel.ForeColor = System.Drawing.SystemColors.Control
        Course_noLabel.Location = New System.Drawing.Point(17, 105)
        Course_noLabel.Name = "Course_noLabel"
        Course_noLabel.Size = New System.Drawing.Size(102, 13)
        Course_noLabel.TabIndex = 6
        Course_noLabel.Text = "COURSE NUMBER"
        '
        'Course_descLabel
        '
        Course_descLabel.AutoSize = True
        Course_descLabel.BackColor = System.Drawing.Color.RoyalBlue
        Course_descLabel.ForeColor = System.Drawing.SystemColors.Control
        Course_descLabel.Location = New System.Drawing.Point(233, 105)
        Course_descLabel.Name = "Course_descLabel"
        Course_descLabel.Size = New System.Drawing.Size(128, 13)
        Course_descLabel.TabIndex = 8
        Course_descLabel.Text = "COURSE DESCRIPTION"
        '
        'Class_timeLabel
        '
        Class_timeLabel.AutoSize = True
        Class_timeLabel.BackColor = System.Drawing.Color.RoyalBlue
        Class_timeLabel.ForeColor = System.Drawing.SystemColors.Control
        Class_timeLabel.Location = New System.Drawing.Point(17, 144)
        Class_timeLabel.Name = "Class_timeLabel"
        Class_timeLabel.Size = New System.Drawing.Size(70, 13)
        Class_timeLabel.TabIndex = 10
        Class_timeLabel.Text = "CLASS TIME"
        '
        'Class_dateLabel
        '
        Class_dateLabel.AutoSize = True
        Class_dateLabel.BackColor = System.Drawing.Color.RoyalBlue
        Class_dateLabel.ForeColor = System.Drawing.SystemColors.Control
        Class_dateLabel.Location = New System.Drawing.Point(233, 144)
        Class_dateLabel.Name = "Class_dateLabel"
        Class_dateLabel.Size = New System.Drawing.Size(73, 13)
        Class_dateLabel.TabIndex = 12
        Class_dateLabel.Text = "CLASS DATE"
        '
        'Max_studentsLabel
        '
        Max_studentsLabel.AutoSize = True
        Max_studentsLabel.BackColor = System.Drawing.Color.RoyalBlue
        Max_studentsLabel.ForeColor = System.Drawing.SystemColors.Control
        Max_studentsLabel.Location = New System.Drawing.Point(17, 183)
        Max_studentsLabel.Name = "Max_studentsLabel"
        Max_studentsLabel.Size = New System.Drawing.Size(92, 13)
        Max_studentsLabel.TabIndex = 14
        Max_studentsLabel.Text = "MAX STUDENTS"
        '
        'Start_DateLabel
        '
        Start_DateLabel.AutoSize = True
        Start_DateLabel.BackColor = System.Drawing.Color.RoyalBlue
        Start_DateLabel.ForeColor = System.Drawing.SystemColors.Control
        Start_DateLabel.Location = New System.Drawing.Point(233, 183)
        Start_DateLabel.Name = "Start_DateLabel"
        Start_DateLabel.Size = New System.Drawing.Size(75, 13)
        Start_DateLabel.TabIndex = 16
        Start_DateLabel.Text = "START DATE"
        '
        'End_DateLabel
        '
        End_DateLabel.AutoSize = True
        End_DateLabel.BackColor = System.Drawing.Color.RoyalBlue
        End_DateLabel.ForeColor = System.Drawing.SystemColors.Control
        End_DateLabel.Location = New System.Drawing.Point(19, 222)
        End_DateLabel.Name = "End_DateLabel"
        End_DateLabel.Size = New System.Drawing.Size(62, 13)
        End_DateLabel.TabIndex = 18
        End_DateLabel.Text = "END DATE"
        '
        'Learning_Hub_DBDataSet
        '
        Me.Learning_Hub_DBDataSet.DataSetName = "Learning_Hub_DBDataSet"
        Me.Learning_Hub_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Course_infoBindingSource
        '
        Me.Course_infoBindingSource.DataMember = "course_info"
        Me.Course_infoBindingSource.DataSource = Me.Learning_Hub_DBDataSet
        '
        'Course_infoTableAdapter
        '
        Me.Course_infoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Connection = Nothing
        Me.TableAdapterManager.course_infoTableAdapter = Nothing
        Me.TableAdapterManager.student_dataTableAdapter = Nothing
        Me.TableAdapterManager.student_infoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Studentlogin.Learning_Hub_DBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Course_infoDataGridView
        '
        Me.Course_infoDataGridView.AutoGenerateColumns = False
        Me.Course_infoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Course_infoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9})
        Me.Course_infoDataGridView.DataSource = Me.Course_infoBindingSource
        Me.Course_infoDataGridView.Location = New System.Drawing.Point(523, 66)
        Me.Course_infoDataGridView.Name = "Course_infoDataGridView"
        Me.Course_infoDataGridView.Size = New System.Drawing.Size(943, 545)
        Me.Course_infoDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "course_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "course_id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "subject"
        Me.DataGridViewTextBoxColumn2.HeaderText = "subject"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "course_no"
        Me.DataGridViewTextBoxColumn3.HeaderText = "course_no"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "course_desc"
        Me.DataGridViewTextBoxColumn4.HeaderText = "course_desc"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "class_time"
        Me.DataGridViewTextBoxColumn5.HeaderText = "class_time"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "class_date"
        Me.DataGridViewTextBoxColumn6.HeaderText = "class_date"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "max_students"
        Me.DataGridViewTextBoxColumn7.HeaderText = "max_students"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Start Date"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Start Date"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "End Date"
        Me.DataGridViewTextBoxColumn9.HeaderText = "End Date"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(500, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(332, 37)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Course Management"
        '
        'Course_idTextBox
        '
        Me.Course_idTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "course_id", True))
        Me.Course_idTextBox.Location = New System.Drawing.Point(20, 82)
        Me.Course_idTextBox.Name = "Course_idTextBox"
        Me.Course_idTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Course_idTextBox.TabIndex = 3
        '
        'SubjectTextBox
        '
        Me.SubjectTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "subject", True))
        Me.SubjectTextBox.Location = New System.Drawing.Point(236, 82)
        Me.SubjectTextBox.Name = "SubjectTextBox"
        Me.SubjectTextBox.Size = New System.Drawing.Size(200, 20)
        Me.SubjectTextBox.TabIndex = 5
        '
        'Course_noTextBox
        '
        Me.Course_noTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "course_no", True))
        Me.Course_noTextBox.Location = New System.Drawing.Point(20, 121)
        Me.Course_noTextBox.Name = "Course_noTextBox"
        Me.Course_noTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Course_noTextBox.TabIndex = 7
        '
        'Course_descTextBox
        '
        Me.Course_descTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "course_desc", True))
        Me.Course_descTextBox.Location = New System.Drawing.Point(236, 121)
        Me.Course_descTextBox.Name = "Course_descTextBox"
        Me.Course_descTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Course_descTextBox.TabIndex = 9
        '
        'Class_timeTextBox
        '
        Me.Class_timeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "class_time", True))
        Me.Class_timeTextBox.Location = New System.Drawing.Point(20, 160)
        Me.Class_timeTextBox.Name = "Class_timeTextBox"
        Me.Class_timeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Class_timeTextBox.TabIndex = 11
        '
        'Class_dateTextBox
        '
        Me.Class_dateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "class_date", True))
        Me.Class_dateTextBox.Location = New System.Drawing.Point(236, 160)
        Me.Class_dateTextBox.Name = "Class_dateTextBox"
        Me.Class_dateTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Class_dateTextBox.TabIndex = 13
        '
        'Max_studentsTextBox
        '
        Me.Max_studentsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Course_infoBindingSource, "max_students", True))
        Me.Max_studentsTextBox.Location = New System.Drawing.Point(20, 199)
        Me.Max_studentsTextBox.Name = "Max_studentsTextBox"
        Me.Max_studentsTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Max_studentsTextBox.TabIndex = 15
        '
        'Start_DateDateTimePicker
        '
        Me.Start_DateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.Course_infoBindingSource, "Start Date", True))
        Me.Start_DateDateTimePicker.Location = New System.Drawing.Point(236, 199)
        Me.Start_DateDateTimePicker.Name = "Start_DateDateTimePicker"
        Me.Start_DateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Start_DateDateTimePicker.TabIndex = 17
        '
        'End_DateDateTimePicker
        '
        Me.End_DateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.Course_infoBindingSource, "End Date", True))
        Me.End_DateDateTimePicker.Location = New System.Drawing.Point(20, 238)
        Me.End_DateDateTimePicker.Name = "End_DateDateTimePicker"
        Me.End_DateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.End_DateDateTimePicker.TabIndex = 19
        '
        'btnAddCourse
        '
        Me.btnAddCourse.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddCourse.Location = New System.Drawing.Point(20, 276)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(75, 23)
        Me.btnAddCourse.TabIndex = 20
        Me.btnAddCourse.Text = "Add"
        Me.btnAddCourse.UseVisualStyleBackColor = True
        '
        'btnRemoveCourse
        '
        Me.btnRemoveCourse.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRemoveCourse.Location = New System.Drawing.Point(102, 275)
        Me.btnRemoveCourse.Name = "btnRemoveCourse"
        Me.btnRemoveCourse.Size = New System.Drawing.Size(75, 23)
        Me.btnRemoveCourse.TabIndex = 21
        Me.btnRemoveCourse.Text = "Remove"
        Me.btnRemoveCourse.UseVisualStyleBackColor = True
        '
        'LogoutLink
        '
        Me.LogoutLink.AutoSize = True
        Me.LogoutLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutLink.Location = New System.Drawing.Point(1426, 23)
        Me.LogoutLink.Name = "LogoutLink"
        Me.LogoutLink.Size = New System.Drawing.Size(60, 18)
        Me.LogoutLink.TabIndex = 23
        Me.LogoutLink.TabStop = True
        Me.LogoutLink.Text = "Logout"
        '
        'AdminControlsLink
        '
        Me.AdminControlsLink.AutoSize = True
        Me.AdminControlsLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdminControlsLink.Location = New System.Drawing.Point(19, 23)
        Me.AdminControlsLink.Name = "AdminControlsLink"
        Me.AdminControlsLink.Size = New System.Drawing.Size(139, 18)
        Me.AdminControlsLink.TabIndex = 22
        Me.AdminControlsLink.TabStop = True
        Me.AdminControlsLink.Text = "< Admin Controls"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox1.Location = New System.Drawing.Point(12, 49)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(439, 268)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.RoyalBlue
        Me.PictureBox2.Location = New System.Drawing.Point(481, 49)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(1013, 581)
        Me.PictureBox2.TabIndex = 25
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Studentlogin.My.Resources.Resources._40567_2
        Me.PictureBox3.Location = New System.Drawing.Point(12, 343)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(439, 247)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 26
        Me.PictureBox3.TabStop = False
        '
        'CourseManagement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1506, 635)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.LogoutLink)
        Me.Controls.Add(Me.AdminControlsLink)
        Me.Controls.Add(Me.btnRemoveCourse)
        Me.Controls.Add(Me.btnAddCourse)
        Me.Controls.Add(End_DateLabel)
        Me.Controls.Add(Me.End_DateDateTimePicker)
        Me.Controls.Add(Start_DateLabel)
        Me.Controls.Add(Me.Start_DateDateTimePicker)
        Me.Controls.Add(Max_studentsLabel)
        Me.Controls.Add(Me.Max_studentsTextBox)
        Me.Controls.Add(Class_dateLabel)
        Me.Controls.Add(Me.Class_dateTextBox)
        Me.Controls.Add(Class_timeLabel)
        Me.Controls.Add(Me.Class_timeTextBox)
        Me.Controls.Add(Course_descLabel)
        Me.Controls.Add(Me.Course_descTextBox)
        Me.Controls.Add(Course_noLabel)
        Me.Controls.Add(Me.Course_noTextBox)
        Me.Controls.Add(SubjectLabel)
        Me.Controls.Add(Me.SubjectTextBox)
        Me.Controls.Add(Course_idLabel)
        Me.Controls.Add(Me.Course_idTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Course_infoDataGridView)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "CourseManagement"
        Me.Text = "CourseManagement"
        CType(Me.Learning_Hub_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course_infoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Learning_Hub_DBDataSet As Learning_Hub_DBDataSet
    Friend WithEvents Course_infoBindingSource As BindingSource
    Friend WithEvents Course_infoTableAdapter As Learning_Hub_DBDataSetTableAdapters.course_infoTableAdapter
    Friend WithEvents TableAdapterManager As Learning_Hub_DBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Course_infoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents Course_idTextBox As TextBox
    Friend WithEvents SubjectTextBox As TextBox
    Friend WithEvents Course_noTextBox As TextBox
    Friend WithEvents Course_descTextBox As TextBox
    Friend WithEvents Class_timeTextBox As TextBox
    Friend WithEvents Class_dateTextBox As TextBox
    Friend WithEvents Max_studentsTextBox As TextBox
    Friend WithEvents Start_DateDateTimePicker As DateTimePicker
    Friend WithEvents End_DateDateTimePicker As DateTimePicker
    Friend WithEvents btnAddCourse As Button
    Friend WithEvents btnRemoveCourse As Button
    Friend WithEvents LogoutLink As LinkLabel
    Friend WithEvents AdminControlsLink As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
End Class
